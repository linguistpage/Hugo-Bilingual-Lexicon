---
word: "true"

title: "Linear Language"

categories: ['']

tags: ['linear', 'language']

arwords: 'لغة خطيّة'

arexps: []

enwords: ['Linear Language']

enexps: []

arlexicons: ['ل']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
