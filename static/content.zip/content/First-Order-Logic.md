---
word: "true"

title: "First-Order Logic"

categories: ['']

tags: ['first', 'order', 'logic']

arwords: 'منطق من الدرجة اﻷولى'

arexps: []

enwords: ['First-Order Logic']

enexps: []

arlexicons: 'ن'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
