---
word: "true"

title: "Constraint-Based Approach"

categories: ['']

tags: ['constraint', 'based', 'approach']

arwords: 'نهج مستند على القيود'

arexps: []

enwords: ['Constraint-Based Approach']

enexps: []

arlexicons: 'ن'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
