---
word: "true"

title: "Perlocutionary Act"

categories: ['']

tags: ['perlocutionary', 'act']

arwords: 'عمل فعلي'

arexps: []

enwords: ['Perlocutionary Act']

enexps: []

arlexicons: ['ع']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
