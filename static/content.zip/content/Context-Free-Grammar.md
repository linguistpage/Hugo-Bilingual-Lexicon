---
word: "true"

title: "Context-Free Grammar"

categories: ['']

tags: ['context', 'free', 'grammar']

arwords: 'قواعد نحو متحرّرة من السياق'

arexps: []

enwords: ['Context-Free Grammar']

enexps: []

arlexicons: 'ق'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
