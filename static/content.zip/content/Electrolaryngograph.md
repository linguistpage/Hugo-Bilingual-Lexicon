---
word: "true"

title: "Electrolaryngograph"

categories: ['']

tags: ['Electrolaryngograph']

arwords: 'رسام الحنجرة الإلكتروني'

arexps: []

enwords: ['Electrolaryngograph']

enexps: []

arlexicons: 'ر'

enlexicons: 'E'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---