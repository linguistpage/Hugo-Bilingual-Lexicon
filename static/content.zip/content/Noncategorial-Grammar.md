---
word: "true"

title: "Noncategorial Grammar"

categories: ['']

tags: ['Noncategorial', 'Grammar']

arwords: 'القواعد غير الفئوية'

arexps: []

enwords: ['Noncategorial Grammar']

enexps: []

arlexicons: 'ق'

enlexicons: 'N'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---