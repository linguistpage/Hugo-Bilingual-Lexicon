---
word: "true"

title: "Lexical Semantic Ambiguity"

categories: ['']

tags: ['Lexical', 'Semantic', 'Ambiguity']

arwords: 'الالتباس الدلالي المعجمي'

arexps: []

enwords: ['Lexical Semantic Ambiguity']

enexps: []

arlexicons: 'ل'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---