---
word: "true"

title: "Binary"

categories: ['']

tags: ['binary']

arwords: 'ثنائي'

arexps: []

enwords: ['Binary']

enexps: []

arlexicons: 'ث'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
