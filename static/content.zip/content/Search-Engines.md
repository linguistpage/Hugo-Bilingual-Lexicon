---
word: "true"

title: "Search Engines"

categories: ['']

tags: ['Search', 'Engines']

arwords: 'محركات البحث'

arexps: []

enwords: ['Search Engines']

enexps: []

arlexicons: 'ح'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---