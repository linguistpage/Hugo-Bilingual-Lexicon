---
word: "true"

title: "Computational Linguistics"

categories: ['']

tags: ['computational', 'linguistics']

arwords: 'علم اللسانيات الحاسوبية'

arexps: []

enwords: ['Computational Linguistics']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
