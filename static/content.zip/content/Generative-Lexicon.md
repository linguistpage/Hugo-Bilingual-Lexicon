---
word: "true"

title: "Generative Lexicon"

categories: ['']

tags: ['generative', 'lexicon']

arwords: 'معجم توليدي'

arexps: []

enwords: ['Generative Lexicon']

enexps: []

arlexicons: 'ع'

enlexicons: ['G']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
