---
word: "true"

title: "Early Generative Phonology"

categories: ['']

tags: ['early', 'generative', 'phonology']

arwords: 'علم اﻷصوات التوليدي اﻷولي'

arexps: []

enwords: ['Early Generative Phonology']

enexps: []

arlexicons: 'ع'

enlexicons: ['E']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
