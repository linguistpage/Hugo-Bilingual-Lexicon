---
word: "true"

title: "Covariance Matrix"

categories: ['']

tags: ['Covariance', 'Matrix']

arwords: 'مصفوفة التَّبايُن'

arexps: []

enwords: ['Covariance Matrix']

enexps: []

arlexicons: 'ص'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---