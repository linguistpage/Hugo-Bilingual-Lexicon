---
word: "true"

title: "Omissions and Oversights"

categories: ['']

tags: ['omissions', 'and', 'oversights']

arwords: 'إغفال وسهو'

arexps: []

enwords: ['Omissions and Oversights']

enexps: []

arlexicons: ['غ']

enlexicons: ['O']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
