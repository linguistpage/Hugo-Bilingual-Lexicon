---
word: "true"

title: "Quantifier Storage"

categories: ['']

tags: ['quantifier', 'storage']

arwords: 'مخزن المحدّد الكمي'

arexps: []

enwords: ['Quantifier Storage']

enexps: []

arlexicons: 'خ'

enlexicons: ['Q']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
