---
word: "true"

title: "Habitual-Repetitive"

categories: ['']

tags: ['habitual', 'repetitive']

arwords: 'تكرار معتاد'

arexps: []

enwords: ['Habitual-Repetitive']

enexps: []

arlexicons: ['ك']

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
