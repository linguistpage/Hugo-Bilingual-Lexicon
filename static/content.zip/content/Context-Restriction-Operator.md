---
word: "true"

title: "Context Restriction Operator"

categories: ['']

tags: ['context', 'restriction', 'operator']

arwords: 'عامل تقييد السياق '

arexps: []

enwords: ['Context Restriction Operator']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
