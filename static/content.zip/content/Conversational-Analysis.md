---
word: "true"

title: "Conversational Analysis"

categories: ['']

tags: ['conversational', 'analysis']

arwords: 'تحليل المحادثات'

arexps: []

enwords: ['Conversational Analysis']

enexps: []

arlexicons: 'ح'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
