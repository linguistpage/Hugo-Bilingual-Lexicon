---
word: "true"

title: "Dominance Relation"

categories: ['']

tags: ['dominance', 'relation']

arwords: 'علاقة هيمنة'

arexps: []

enwords: ['Dominance Relation']

enexps: []

arlexicons: 'ع'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
