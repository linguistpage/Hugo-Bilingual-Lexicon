---
word: "true"

title: "Bare Answer Phrase"

categories: ['Linguistics']

tags: ['bare', 'answer', 'phrase']

arwords: 'عبارة إجابة مجرّدة'

arexps: []

enwords: ['Bare Answer Phrase']

enexps: []

arlexicons: 'ع'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
