---
word: "true"

title: "Exponential Number"

categories: ['']

tags: ['exponential', 'number']

arwords: 'عدد أسّي'

arexps: []

enwords: ['Exponential Number']

enexps: []

arlexicons: 'ع'

enlexicons: ['E']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
