---
word: "true"

title: "Asymptotic Growth"

categories: ['Computer Science']

tags: ['asymptotic', 'growth']

arwords: 'نمو مقارب'

arexps: []

enwords: ['Asymptotic Growth']

enexps: []

arlexicons: 'ن'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
