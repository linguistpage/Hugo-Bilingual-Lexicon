---
word: "true"

title: "Human Language Technologies-HLT"

categories: ['']

tags: ['Human', 'Language', 'Technologies', 'HLT']

arwords: 'تقنيات اللغة الطبيعية (الإنسانية)'

arexps: []

enwords: ['Human Language Technologies-HLT']

enexps: []

arlexicons: 'ت'

enlexicons: 'H'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---