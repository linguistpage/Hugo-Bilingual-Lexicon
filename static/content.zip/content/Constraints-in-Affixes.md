---
word: "true"

title: "Constraints in Affixes"

categories: ['']

tags: ['constraints', 'in', 'affixes']

arwords: 'قيود على اللواحق'

arexps: []

enwords: ['Constraints in Affixes']

enexps: []

arlexicons: 'ق'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
