---
word: "true"

title: "Sense-Enumerative"

categories: ['']

tags: ['sense', 'enumerative']

arwords: 'متعدّد المعاني'

arexps: []

enwords: ['Sense-Enumerative']

enexps: []

arlexicons: ['ع']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
