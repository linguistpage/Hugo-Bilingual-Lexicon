---
word: "true"

title: "Bare Sluicing"

categories: ['']

tags: ['bare', 'sluicing']

arwords: 'استثناء مجرّد'

arexps: []

enwords: ['Bare Sluicing']

enexps: []

arlexicons: 'ث'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
