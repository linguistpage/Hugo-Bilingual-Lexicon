---
word: "true"

title: "Abstraction"

categories: ['']

tags: ['Abstraction']

arwords: 'التلخيص'

arexps: []

enwords: ['Abstraction']

enexps: []

arlexicons: 'ل'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---