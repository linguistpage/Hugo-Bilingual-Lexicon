---
word: "true"

title: "Semilinear Set"

categories: ['']

tags: ['semilinear', 'set']

arwords: 'مجموعة شبه خطية'

arexps: []

enwords: ['Semilinear Set']

enexps: []

arlexicons: 'ج'

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
