---
word: "true"

title: "Computational Dialogue"

categories: ['']

tags: ['computational', 'dialogue']

arwords: 'حوار حاسوبي'

arexps: []

enwords: ['Computational Dialogue']

enexps: []

arlexicons: 'ح'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
