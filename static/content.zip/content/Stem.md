---
word: "true"

title: "Stem"

categories: ['']

tags: ['stem']

arwords: 'جذع'

arexps: []

enwords: ['Stem']

enexps: []

arlexicons: ['ج']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
