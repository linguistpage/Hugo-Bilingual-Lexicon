---
word: "true"

title: "Morphological Ambiguity"

categories: ['']

tags: ['Morphological', 'Ambiguity']

arwords: 'الالتباس الصرفي'

arexps: []

enwords: ['Morphological Ambiguity']

enexps: []

arlexicons: 'ل'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---