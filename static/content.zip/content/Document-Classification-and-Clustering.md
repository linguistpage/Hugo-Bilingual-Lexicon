---
word: "true"

title: "Document Classification and Clustering"

categories: ['']

tags: ['Document', 'Classification', 'and', 'Clustering']

arwords: 'تصنيف وتجميع الوثائق'

arexps: []

enwords: ['Document Classification and Clustering']

enexps: []

arlexicons: 'ص'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---