---
word: "true"

title: "Parameters of the Plan"

categories: ['']

tags: ['parameters', 'of', 'the', 'plan']

arwords: 'مؤشّرات الخطة'

arexps: []

enwords: ['Parameters of the Plan']

enexps: []

arlexicons: 'أ'

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
