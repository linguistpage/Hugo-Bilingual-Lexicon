---
word: "true"

title: "Parameterized"

categories: ['']

tags: ['parameterized']

arwords: 'مؤشّر'

arexps: []

enwords: ['Parameterized']

enexps: []

arlexicons: 'أ'

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
