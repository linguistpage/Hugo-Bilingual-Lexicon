---
word: "true"

title: "Intensional"

categories: ['']

tags: ['intensional']

arwords: 'قصديّة'

arexps: []

enwords: ['Intensional']

enexps: []

arlexicons: ['ق']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
