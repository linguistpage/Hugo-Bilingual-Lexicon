---
word: "true"

title: "Duration"

categories: ['']

tags: ['Duration']

arwords: 'فترة'

arexps: []

enwords: ['Duration']

enexps: []

arlexicons: 'ف'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---