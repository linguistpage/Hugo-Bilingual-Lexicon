---
word: "true"

title: "Constitutive"

categories: ['']

tags: ['constitutive']

arwords: 'تكوينية'

arexps: []

enwords: ['Constitutive']

enexps: []

arlexicons: 'ك'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
