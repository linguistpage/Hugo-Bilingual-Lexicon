---
word: "true"

title: "Compiler"

categories: ['']

tags: ['compiler']

arwords: 'مُجمِّع'

arexps: []

enwords: ['Compiler']

enexps: []

arlexicons: 'ج'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
