---
word: "true"

title: "BLEU Score"

categories: ['']

tags: ['BLEU', 'Score']

arwords: 'مُقَيِّم بلو'

arexps: []

enwords: ['BLEU Score']

enexps: []

arlexicons: 'ق'

enlexicons: 'B'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---