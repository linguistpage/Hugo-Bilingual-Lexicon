---
word: "true"

title: "Concatenations"

categories: ['']

tags: ['concatenations']

arwords: 'حروف الأبجدية المترابطة'

arexps: []

enwords: ['Concatenations']

enexps: []

arlexicons: 'ح'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
