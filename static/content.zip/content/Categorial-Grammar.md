---
word: "true"

title: "Categorial Grammar"

categories: ['']

tags: ['Categorial', 'Grammar']

arwords: 'الفئات النحوية'

arexps: []

enwords: ['Categorial Grammar']

enexps: []

arlexicons: 'ف'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
------
word: "true"

title: "Categorial Grammar"

categories: ['']

tags: ['categorial', 'grammar']

arwords: 
 - 'الفئات النحوية'
 - 'قواعد النحو التصنيفي'

arexps: []

enwords: ['Categorial Grammar']

enexps: []

arlexicons: 
 - 'ف'
 - 'ق'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
