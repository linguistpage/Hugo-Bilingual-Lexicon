---
word: "true"

title: "Diacritization"

categories: ['']

tags: ['Diacritization']

arwords: 'التشكيل الآلي'

arexps: []

enwords: ['Diacritization']

enexps: []

arlexicons: 'ش'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---