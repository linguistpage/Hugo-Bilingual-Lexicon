---
word: "true"

title: "Computer-Aided Language Learning"

categories: ['']

tags: ['Computer', 'Aided', 'Language', 'Learning']

arwords: 'تعلم اللغات بمساعدة الحاسوب'

arexps: []

enwords: ['Computer-Aided Language Learning']

enexps: []

arlexicons: 'ع'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---