---
word: "true"

title: "In Fixation Data"

categories: ['']

tags: ['in', 'fixation', 'data']

arwords: 'بيانات الزوائد الوسطية'

arexps: []

enwords: ['In Fixation Data']

enexps: []

arlexicons: ['ب']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
