---
word: "true"

title: "Mathematical Linguistics"

categories: ['']

tags: ['mathematical', 'linguistics']

arwords: 'علم اللغة الرياضي'

arexps: []

enwords: ['Mathematical Linguistics']

enexps: []

arlexicons: ['ع']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
