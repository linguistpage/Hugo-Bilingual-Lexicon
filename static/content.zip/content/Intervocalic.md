---
word: "true"

title: "Intervocalic"

categories: ['']

tags: ['intervocalic']

arwords: 'ساكن بين صائتين'

arexps: []

enwords: ['Intervocalic']

enexps: []

arlexicons: ['س']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
