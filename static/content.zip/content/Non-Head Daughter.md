---
word: "true"

title: "Non-Head Daughter"

categories: ['']

tags: ['non', 'head', 'daughter']

arwords: 'فرع غير رأسي'

arexps: []

enwords: ['Non-Head Daughter']

enexps: []

arlexicons: ['ف']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
