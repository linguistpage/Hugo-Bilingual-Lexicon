---
word: "true"

title: "Morphic Image"

categories: ['']

tags: ['morphic', 'image']

arwords: 'صورة مطابقة'

arexps: []

enwords: ['Morphic Image']

enexps: []

arlexicons: ['ص']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
