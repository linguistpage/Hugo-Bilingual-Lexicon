---
word: "true"

title: "Continuation Class"

categories: ['']

tags: ['continuation', 'class']

arwords: 'فئة الاستمرارية'

arexps: []

enwords: ['Continuation Class']

enexps: []

arlexicons: 'ف'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
