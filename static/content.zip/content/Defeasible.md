---
word: "true"

title: "Defeasible"

categories: ['']

tags: ['defeasible']

arwords: 'قابلة للرفض'

arexps: []

enwords: ['Defeasible']

enexps: []

arlexicons: 'ق'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
