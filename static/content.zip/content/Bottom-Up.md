---
word: "true"

title: "Bottom Up"

categories: ['']

tags: ['bottom', 'up']

arwords: 'من اﻷسفل إلى اﻷعلى'

arexps: []

enwords: ['Bottom Up']

enexps: []

arlexicons: ''

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
