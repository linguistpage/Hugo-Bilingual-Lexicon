---
word: "true"

title: "Order"

categories: ['']

tags: ['order']

arwords: 'ترتيب'

arexps: []

enwords: ['Order']

enexps: []

arlexicons: ['ر']

enlexicons: ['O']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
