---
word: "true"

title: "Auxiliary Verb"

categories: ['']

tags: ['Auxiliary', 'Verb']

arwords: 'فعل مساعد'

arexps: []

enwords: ['Auxiliary Verb']

enexps: []

arlexicons: 'ف'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---