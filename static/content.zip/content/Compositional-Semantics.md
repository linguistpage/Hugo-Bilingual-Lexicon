---
word: "true"

title: "Compositional Semantics"

categories: ['']

tags: ['compositional', 'semantics']

arwords: 'علم الدلالة التركيبي'

arexps: []

enwords: ['Compositional Semantics']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
