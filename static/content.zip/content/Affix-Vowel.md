---
word: "true"

title: "Affix Vowel"

categories: ['Linguistics']

tags: ['affix', 'vowel']

arwords: 'الحرف الصائت للاحقة الأمامية'
arwords2: 'حرف العلة'

arexps: []

enwords: ['Affix Vowel']

enexps: []

arlexicons: 'ح'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
