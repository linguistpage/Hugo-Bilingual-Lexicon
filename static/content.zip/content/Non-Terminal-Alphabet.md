---
word: "true"

title: "Non-Terminal Alphabet"

categories: ['']

tags: ['non', 'terminal', 'alphabet']

arwords: 'أبجدية غير نهائية'

arexps: []

enwords: ['Non-Terminal Alphabet']

enexps: []

arlexicons: ['أ']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
