---
word: "true"

title: "Approximation"

categories: ['Mathematics']

tags: ['approximation']

arwords: 'تقريب'

arexps: []

enwords: ['Approximation']

enexps: []

arlexicons: 'ق'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
