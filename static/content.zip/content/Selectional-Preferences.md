---
word: "true"

title: "Selectional Preferences"

categories: ['']

tags: ['selectional', 'preferences']

arwords: 'أفضليات اختيارية'

arexps: []

enwords: ['Selectional Preferences']

enexps: []

arlexicons: ['أ']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
