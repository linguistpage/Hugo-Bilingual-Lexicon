---
word: "true"

title: "Asymptotic Bound"

categories: ['']

tags: ['asymptotic', 'bound']

arwords: 'حدّ مقارب'

arexps: []

enwords: ['Asymptotic Bound']

enexps: []

arlexicons: 'ح'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
