---
word: "true"

title: "Dictation Engine"
enwords: "Dictation Engine"
arwords: "مصحح إملائي"
categories : ['Machine Learning', 'Dictation', 'Human Language Technologies']
tags : ['Dictation', 'Engine']
translators : ['Tarek Oraby']
arlexicons : ['ص']
enlexicons : ['D']
authors : ['Tarek Oraby']
citations: ['N/A']
sources: "N/A"
slug: ""
---
