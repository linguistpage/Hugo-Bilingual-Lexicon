---
word: "true"

title: "Isomorphism"

categories: ['']

tags: ['isomorphism']

arwords: 'تماثل'

arexps: []

enwords: ['Isomorphism']

enexps: []

arlexicons: ['م']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
