---
word: "true"

title: "Continuation Passing"

categories: ['']

tags: ['continuation', 'passing']

arwords: 'تمرير الاستمرارية'

arexps: []

enwords: ['Continuation Passing']

enexps: []

arlexicons: 'م'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
