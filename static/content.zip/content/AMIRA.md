---
word: "true"

title: "AMIRA"

categories: ['']

tags: ['AMIRA']

arwords: 'حزمة أدوات برمجية (أميرة)'

arexps: []

enwords: ['AMIRA']

enexps: []

arlexicons: 'ح'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---