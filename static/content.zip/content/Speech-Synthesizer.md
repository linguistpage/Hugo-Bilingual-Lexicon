---
word: "true"

title: "Speech Synthesizer"

categories: ['']

tags: ['Speech', 'Synthesizer']

arwords: 'ناطق الكلام'

arexps: []

enwords: ['Speech Synthesizer']

enexps: []

arlexicons: 'ن'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---