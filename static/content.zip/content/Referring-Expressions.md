---
word: "true"

title: "Referring Expressions"

categories: ['']

tags: ['referring', 'expressions']

arwords: 'تعابير الإشارة'

arexps: []

enwords: ['Referring Expressions']

enexps: []

arlexicons: ['ع']

enlexicons: ['R']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
