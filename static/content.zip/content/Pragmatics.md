---
word: "true"

title: "Pragmatics"

categories: ['']

tags: ['pragmatics']

arwords: 'المغزى السياقي للكلام'
arwords2: 'براغماتيات'

arexps: []

enwords: ['Pragmatics']

enexps: []

arlexicons: 'غ'
arlexicons2: 'ب'

enlexicons: 'P'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
