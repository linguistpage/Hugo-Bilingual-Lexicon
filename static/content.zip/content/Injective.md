---
word: "true"

title: "Injective"

categories: ['']

tags: ['injective']

arwords: 'تناظر أحادي'

arexps: []

enwords: ['Injective']

enexps: []

arlexicons: ['ن']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
