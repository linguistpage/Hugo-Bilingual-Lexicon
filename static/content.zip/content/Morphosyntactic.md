---
word: "true"

title: "Morphosyntactic"

categories: ['']

tags: ['morphosyntactic']

arwords: 'صرفي نحوي'

arexps: []

enwords: ['Morphosyntactic']

enexps: []

arlexicons: ['ص']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
