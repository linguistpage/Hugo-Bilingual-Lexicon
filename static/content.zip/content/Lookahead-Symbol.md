---
word: "true"

title: "Lookahead Symbol"

categories: ['']

tags: ['lookahead', 'symbol']

arwords: 'رمز استباق'

arexps: []

enwords: ['Lookahead Symbol']

enexps: []

arlexicons: ['ر']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
