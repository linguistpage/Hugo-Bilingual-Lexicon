---
word: "true"

title: "Language Recognition"
enwords: "Language Recognition"
arwords: "التعرف الآلي على اللغة"
categories : ['Human Language Technologies']
tags : ['Language','Recognition']
translators : ['Tarek Oraby']
arlexicons : ['ع']
enlexicons : ['L']
authors : ['Tarek Oraby']
citations: ['N/A']
sources: "N/A"
slug: ""
---