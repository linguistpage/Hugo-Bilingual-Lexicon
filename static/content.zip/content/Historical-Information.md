---
word: "true"

title: "Historical Information"

categories: ['']

tags: ['Historical', 'Information']

arwords: 'المعلومات التاريخية'

arexps: []

enwords: ['Historical Information']

enexps: []

arlexicons: 'ع'

enlexicons: 'H'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---