---
word: "true"

title: "Illocutionary Force"

categories: ['']

tags: ['illocutionary', 'force']

arwords: 'قوة تعبيرية'

arexps: []

enwords: ['Illocutionary Force']

enexps: []

arlexicons: ['ق']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
