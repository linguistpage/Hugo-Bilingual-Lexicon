---
word: "true"

title: "Tree Language"

categories: ['']

tags: ['tree', 'language']

arwords: 'لغة تفرعية'

arexps: []

enwords: ['Tree Language']

enexps: []

arlexicons: ['ل']

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
