---
word: "true"

title: "Long-Distance Dependency"

categories: ['']

tags: ['long', 'distance', 'dependency']

arwords: 'تبعية بعيدة'

arexps: []

enwords: ['Long-Distance Dependency']

enexps: []

arlexicons: ['ت']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
