---
word: "true"

title: "Computer Aided Font Learning"

categories: ['NLP']

tags: ['computer','aided', 'computer-aided', 'font','learning']

arwords: 'تعلم الخط بمساعدة الحاسوب'

arexps: []

enwords: ['Computer Aided Font Learning']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Oraby']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---