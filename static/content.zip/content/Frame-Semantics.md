---
word: "true"

title: "Frame Semantics"

categories: ['']

tags: ['frame', 'semantics']

arwords: 'دلالة الإطار'

arexps: []

enwords: ['Frame Semantics']

enexps: []

arlexicons: ['د']

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
