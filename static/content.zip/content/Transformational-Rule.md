---
word: "true"

title: "Transformational Rule"

categories: ['']

tags: ['Transformational', 'Rule']

arwords: 'قواعد التحويل'

arexps: []

enwords: ['Transformational Rule']

enexps: []

arlexicons: 'ق'

enlexicons: 'T'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---