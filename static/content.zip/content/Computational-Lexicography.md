---
word: "true"

title: "Computational Lexicography"

categories: ['']

tags: ['computational', 'lexicography']

arwords: 'صناعة المعاجم الحاسوبية'

arexps: []

enwords: ['Computational Lexicography']

enexps: []

arlexicons: 'ص'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
