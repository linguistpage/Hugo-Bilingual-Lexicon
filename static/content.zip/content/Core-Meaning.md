---
word: "true"

title: "Core Meaning"

categories: ['']

tags: ['core', 'Meaning']

arwords: 'معنى أساسي'

arexps: []

enwords: ['Core Meaning']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
