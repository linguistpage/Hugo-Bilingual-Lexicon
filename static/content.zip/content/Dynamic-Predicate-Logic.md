---
word: "true"

title: "Dynamic Predicate Logic"

categories: ['']

tags: ['dynamic', 'predicate', 'logic']

arwords: 'منطق المسند الديناميكي'

arexps: []

enwords: ['Dynamic Predicate Logic']

enexps: []

arlexicons: 'ن'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
