---
word: "true"

title: "Deterministic Case"

categories: ['']

tags: ['deterministic', 'case']

arwords: 'حالة قطعية'

arexps: []

enwords: ['Deterministic Case']

enexps: []

arlexicons: 'ح'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
