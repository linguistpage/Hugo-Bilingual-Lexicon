---
word: "true"

title: "Indexing Scheme"

categories: ['']

tags: ['indexing', 'scheme']

arwords: 'نظام الدليل'

arexps: []

enwords: ['Indexing Scheme']

enexps: []

arlexicons: 'ن'

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
