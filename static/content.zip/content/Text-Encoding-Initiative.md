---
word: "true"

title: "Text-Encoding Initiative"

categories: ['']

tags: ['text', 'encoding', 'initiative']

arwords: 'مبادرة ترميز النصوص'

arexps: []

enwords: ['Text-Encoding Initiative']

enexps: []

arlexicons: ['ب']

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
