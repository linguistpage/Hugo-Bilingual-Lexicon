---
word: "true"

title: "Polysynthetic Language"

categories: ['']

tags: ['polysynthetic', 'language']

arwords: 'لغة تركيبية'

arexps: []

enwords: ['Polysynthetic Language']

enexps: []

arlexicons: ['ل']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
