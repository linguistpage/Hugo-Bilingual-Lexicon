---
word: "true"

title: "Automatic Handwriting Recognition"

categories: ['']

tags: ['Automatic', 'Handwriting', 'Recognition']

arwords: 'التعرف الآلي على الكتابة'

arexps: []

enwords: ['Automatic Handwriting Recognition']

enexps: []

arlexicons: 'ع'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---