---
word: "true"

title: "Syntactic Representations"

categories: ['']

tags: ['syntactic', 'representations']

arwords: 'تمثيل نحوي'

arexps: []

enwords: ['Syntactic Representations']

enexps: []

arlexicons: ['م']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
