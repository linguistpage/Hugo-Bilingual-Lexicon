---
word: "true"

title: "Asymptotic Upper Bound"

categories: ['']

tags: ['asymptotic', 'upper', 'bound']

arwords: 'حدّ مقارب أعلى'

arexps: []

enwords: ['Asymptotic Upper Bound']

enexps: []

arlexicons: 'ح'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
