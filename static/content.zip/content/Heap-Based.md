---
word: "true"

title: "Heap-Based"

categories: ['']

tags: ['heap', 'based']

arwords: 'مستند على الكومة'

arexps: []

enwords: ['Heap-Based']

enexps: []

arlexicons: 'س'

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
