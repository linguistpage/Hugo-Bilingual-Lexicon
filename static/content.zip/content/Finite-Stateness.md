---
word: "true"

title: "Finite-Stateness"

categories: ['']

tags: ['finite', 'stateness']

arwords: 'محدودية الحالات'

arexps: []

enwords: ['Finite-Stateness']

enexps: []

arlexicons: 'ح'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
