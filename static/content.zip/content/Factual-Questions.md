---
word: "true"

title: "Factual Questions"

categories: ['']

tags: ['Factual', 'Questions']

arwords: 'أسئلة محددة اﻹجابة'
arwords2: 'أسئلة واقعية'

arexps: []

enwords: ['Factual Questions']

enexps: []

arlexicons: 'س'

enlexicons: 'F'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---