---
word: "true"

title: "Discourse Plan"

categories: ['']

tags: ['discourse', 'plan']

arwords: 'خطة الخطاب'

arexps: []

enwords: ['Discourse Plan']

enexps: []

arlexicons: 'خ'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
