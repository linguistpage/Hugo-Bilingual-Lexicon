---
word: "true"

title: "Roots"

categories: ['']

tags: ['Roots']

arwords: 'الجذور'

arexps: []

enwords: ['Roots']

enexps: []

arlexicons: 'ج'

enlexicons: 'R'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---