---
word: "true"

title: "Referring Expression"

categories: ['']

tags: ['referring', 'expression']

arwords: 'عبارة إشارة'

arexps: []

enwords: ['Referring Expression']

enexps: []

arlexicons: ['ع']

enlexicons: ['R']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
