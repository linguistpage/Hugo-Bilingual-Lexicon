---
word: "true"

title: "Discrete Cosine Transform"

categories: ['']

tags: ['Discrete', 'Cosine', 'Transform']

arwords: 'تحويل جيب التَّمام المتَقَطِّع'

arexps: []

enwords: ['Discrete Cosine Transform']

enexps: []

arlexicons: 'ح'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---