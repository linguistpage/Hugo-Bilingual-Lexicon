---
word: "true"

title: "Center for Computational Learning Systems-CCLS"

categories: ['']

tags: ['Center', 'for', 'Computational', 'Learning', 'Systems', 'CCLS']

arwords: 'مركز أنظمة التعلم الحاسوبية'

arexps: []

enwords: ['Center for Computational Learning Systems-CCLS']

enexps: []

arlexicons: 'ر'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---