---
word: "true"

title: "Complexity Measures"

categories: ['']

tags: ['complexity', 'measures']

arwords: 'مقاييس التعقيد'

arexps: []

enwords: ['Complexity Measures']

enexps: []

arlexicons: 'ق'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
