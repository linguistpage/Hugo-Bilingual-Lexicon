---
word: "true"

title: "Cross-Word"

categories: ['']

tags: ['Cross', 'Word']

arwords: 'عبارة للكلمات'

arexps: []

enwords: ['Cross-Word']

enexps: []

arlexicons: 'ع'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---