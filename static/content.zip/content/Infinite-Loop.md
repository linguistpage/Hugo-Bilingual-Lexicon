---
word: "true"

title: "Infinite Loop"

categories: ['']

tags: ['infinite', 'loop']

arwords: 'حلقة لا نهائية'

arexps: []

enwords: ['Infinite Loop']

enexps: []

arlexicons: ['ح']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
