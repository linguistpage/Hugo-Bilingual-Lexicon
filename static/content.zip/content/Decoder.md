---
word: "true"

title: "Decoder"

categories: ['']

tags: ['Decoder']

arwords: 'فاكّ الشَّفرة'

arexps: []

enwords: ['Decoder']

enexps: []

arlexicons: 'ف'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---