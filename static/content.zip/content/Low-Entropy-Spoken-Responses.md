---
word: "true"

title: "Low Entropy Spoken Responses"

categories: ['']

tags: ['Low', 'Entropy', 'Spoken', 'Responses']

arwords: 'اﻹجابات المنطوقة بفوضى منخفضة'

arexps: []

enwords: ['Low Entropy Spoken Responses']

enexps: []

arlexicons: 'ج'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---