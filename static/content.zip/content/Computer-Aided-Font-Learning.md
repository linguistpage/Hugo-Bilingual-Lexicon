---
word: "true"

title: "Computer-Aided Font Learning"

categories: ['']

tags: ['Computer', 'Aided', 'Font', 'Learning']

arwords: 'تعلم الخط بمساعدة الحاسوب'

arexps: []

enwords: ['Computer-Aided Font Learning']

enexps: []

arlexicons: 'ع'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---