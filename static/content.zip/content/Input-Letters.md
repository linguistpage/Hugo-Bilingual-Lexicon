---
word: "true"

title: "Input Letters"

categories: ['']

tags: ['input', 'letters']

arwords: 'حروف إدخال'

arexps: []

enwords: ['Input Letters']

enexps: []

arlexicons: ['ح']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
