---
word: "true"

title: "Plan Instantiation"

categories: ['']

tags: ['plan', 'instantiation']

arwords: 'تجسيد الخطة'

arexps: []

enwords: ['Plan Instantiation']

enexps: []

arlexicons: ['ج']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
