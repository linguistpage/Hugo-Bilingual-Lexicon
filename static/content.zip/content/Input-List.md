---
word: "true"

title: "Input List"

categories: ['']

tags: ['input', 'list']

arwords: 'قائمة مدخلات'

arexps: []

enwords: ['Input List']

enexps: []

arlexicons: ['ق']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
