---
word: "true"

title: "Letter Trees"

categories: ['']

tags: ['letter', 'trees']

arwords: 'حروف شجرية'

arexps: []

enwords: ['Letter Trees']

enexps: []

arlexicons: ['ح']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
