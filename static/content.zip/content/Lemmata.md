---
word: "true"

title: "Lemmata"

categories: ['']

tags: ['Lemmata']

arwords: 'فروع'

arexps: []

enwords: ['Lemmata']

enexps: []

arlexicons: 'ف'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---