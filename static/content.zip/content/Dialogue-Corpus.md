---
word: "true"

title: "Dialogue Corpus"

categories: ['']

tags: ['dialogue', 'corpus']

arwords: 'مدونة حوارات'

arexps: []

enwords: ['Dialogue Corpus']

enexps: []

arlexicons: 'د'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
