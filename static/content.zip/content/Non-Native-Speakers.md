---
word: "true"

title: "Non-Native Speakers"

categories: ['']

tags: ['Non', 'Native', 'Speakers']

arwords: 'غير ناطقي اللغة اﻷصلية'

arexps: []

enwords: ['Non-Native Speakers']

enexps: []

arlexicons: 'غ'

enlexicons: 'N'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---