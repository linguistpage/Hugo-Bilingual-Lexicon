---
word: "true"

title: "Possessive Infix"

categories: ['']

tags: ['possessive', 'infix']

arwords: 'لاحقة التملّك الوسطية'

arexps: []

enwords: ['Possessive Infix']

enexps: []

arlexicons: ['ل']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
