---
word: "true"

title: "Feature-Structure"

categories: ['']

tags: ['feature', 'structure']

arwords: 'تركيبات الخواص'

arexps: []

enwords: ['Feature-Structure']

enexps: []

arlexicons: 'ر'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
