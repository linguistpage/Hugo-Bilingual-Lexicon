---
word: "true"

title: "Government and Binding Theory"

categories: ['']

tags: ['government', 'and', 'binding', 'theory']

arwords: 'نظرية الحكم واﻹلزام'

arexps: []

enwords: ['Government and Binding Theory']

enexps: []

arlexicons: 'ن'

enlexicons: ['G']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
