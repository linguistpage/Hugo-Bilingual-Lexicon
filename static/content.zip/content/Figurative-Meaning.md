---
word: "true"

title: "Figurative Meaning"

categories: ['']

tags: ['Figurative', 'Meaning']

arwords: 'المعنى المجازي'

arexps: []

enwords: ['Figurative Meaning']

enexps: []

arlexicons: 'ع'

enlexicons: 'F'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---