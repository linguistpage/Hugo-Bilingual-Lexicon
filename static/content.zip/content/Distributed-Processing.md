---
word: "true"

title: "Distributed Processing"

categories: ['']

tags: ['Distributed', 'Processing']

arwords: 'حوسبة موزّعة'

arexps: []

enwords: ['Distributed Processing']

enexps: []

arlexicons: 'ح'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---