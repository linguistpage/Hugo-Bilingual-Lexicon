---
word: "true"

title: "Minimalist Program"

categories: ['']

tags: ['minimalist', 'program']

arwords: 'برنامج الحد اﻷدني'

arexps: []

enwords: ['Minimalist Program']

enexps: []

arlexicons: ['ب']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
