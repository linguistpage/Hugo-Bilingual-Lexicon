---
word: "true"

title: "Generalized Phrase Structure Grammar"

categories: ['']

tags: ['generalized', 'phrase', 'structure', 'grammar']

arwords: 'قواعد النحو العامة لتركيب العبارات'

arexps: []

enwords: ['Generalized Phrase Structure Grammar']

enexps: []

arlexicons: ['ق']

enlexicons: ['G']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
