---
word: "true"

title: "Concordancer"

categories: ['']

tags: ['Concordancer']

arwords: 'الكشاف السياقي'

arexps: []

enwords: ['Concordancer']

enexps: []

arlexicons: 'ك'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---