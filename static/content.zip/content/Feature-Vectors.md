---
word: "true"

title: "Feature Vectors"

categories: ['']

tags: ['Feature', 'Vectors']

arwords: 'مُتَّجهات السِّمات'

arexps: []

enwords: ['Feature Vectors']

enexps: []

arlexicons: 'و'

enlexicons: 'F'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---