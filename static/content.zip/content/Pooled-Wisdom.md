---
word: "true"

title: "Pooled Wisdom"

categories: ['']

tags: ['Pooled', 'Wisdom']

arwords: 'الحكمة الجمعية'

arexps: []

enwords: ['Pooled Wisdom']

enexps: []

arlexicons: 'ح'

enlexicons: 'P'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---