---
word: "true"

title: "Qatar Computing Research Institute-QCRI"

categories: ['']

tags: ['Qatar', 'Computing', 'Research', 'Institute', 'QCRI']

arwords: 'معهد قطر لبحوث الحوسبة'

arexps: []

enwords: ['Qatar Computing Research Institute-QCRI']

enexps: []

arlexicons: 'ع'

enlexicons: 'Q'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---