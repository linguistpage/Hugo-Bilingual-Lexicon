---
word: "true"

title: "Likelihood Ratio"

categories: ['']

tags: ['Likelihood', 'Ratio']

arwords: 'نسبة اﻷرجحيَّة'

arexps: []

enwords: ['Likelihood Ratio']

enexps: []

arlexicons: 'ن'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---