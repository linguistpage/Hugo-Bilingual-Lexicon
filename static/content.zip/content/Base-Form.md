---
word: "true"

title: "Base Form"

categories: ['']

tags: ['base', 'form']

arwords: 'شكل أساسي'

arexps: []

enwords: ['Base Form']

enexps: []

arlexicons: 'ش'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
