---
word: "true"

title: "Asymmetric"

categories: ['']

tags: ['asymmetric']

arwords: 'غير متماثل'

arexps: []

enwords: ['Asymmetric']

enexps: []

arlexicons: 'غ'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
