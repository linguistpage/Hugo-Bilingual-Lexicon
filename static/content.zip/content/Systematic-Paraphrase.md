---
word: "true"

title: "Systematic Paraphrase"

categories: ['']

tags: ['systematic', 'paraphrase']

arwords: 'إعادة منظّمة لصياغة العبارات'

arexps: []

enwords: ['Systematic Paraphrase']

enexps: []

arlexicons: ['ع']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
