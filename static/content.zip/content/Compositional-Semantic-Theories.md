---
word: "true"

title: "Compositional Semantic Theories"

categories: ['']

tags: ['compositional', 'semantic', 'theories']

arwords: 'نظريات الدلالة التركيبية'

arexps: []

enwords: ['Compositional Semantic Theories']

enexps: []

arlexicons: 'ن'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
