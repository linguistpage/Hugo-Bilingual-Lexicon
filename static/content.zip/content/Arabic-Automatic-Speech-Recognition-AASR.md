---
word: "true"

title: "Arabic Automatic Speech Recognition-AASR"

categories: ['']

tags: ['Arabic', 'Automatic', 'Speech', 'Recognition', 'AASR']

arwords: 'التعرف الآلي على الكلام العربي'

arexps: []

enwords: ['Arabic Automatic Speech Recognition-AASR']

enexps: []

arlexicons: 'ع'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---