---
word: "true"

title: "Union"

categories: ['']

tags: ['union']

arwords: 'اتحاد'

arexps: []

enwords: ['Union']

enexps: []

arlexicons: ['و']

enlexicons: ['U']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
