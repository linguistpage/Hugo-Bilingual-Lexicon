---
word: "true"

title: "Human-Human Dialogue"

categories: ['']

tags: ['human', 'human', 'dialogue']

arwords: 'حوار بين الإنسان والإنسان'

arexps: []

enwords: ['Human-Human Dialogue']

enexps: []

arlexicons: ['ح']

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
