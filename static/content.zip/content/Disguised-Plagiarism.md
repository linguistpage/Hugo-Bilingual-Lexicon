---
word: "true"

title: "Disguised Plagiarism"

categories: ['']

tags: ['Disguised', 'Plagiarism']

arwords: 'الاحتيال المتنكر'

arexps: []

enwords: ['Disguised Plagiarism']

enexps: []

arlexicons: 'ح'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---