---
word: "true"

title: "Code Locality"
categories: ['']
tags: ['code', 'locality']
arwords: 'محل شفرة المصدر'
arexps: []
enwords: ['Code Locality']
enexps: []
arlexicons: 'ح'
enlexicons: ['C']
authors: ['Ruqayya Roshdy']
translators: ['Tarek Ibrahim']
citations: ['دليل أكسفورد في السانيات الحاسوبية']
sources: ['المنظمة العربية للترجمة']
slug: ""
---
