---
word: "true"

title: "Kymograph"

categories: ['']

tags: ['Kymograph']

arwords: 'الكيموجراف'

arexps: []

enwords: ['Kymograph']

enexps: []

arlexicons: 'ك'

enlexicons: 'K'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---