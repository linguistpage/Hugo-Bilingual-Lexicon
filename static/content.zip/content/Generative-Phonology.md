---
word: "true"

title: "Generative Phonology"

categories: ['']

tags: ['generative', 'phonology']

arwords: 'علم اﻷصوات التوليدي'

arexps: []

enwords: ['Generative Phonology']

enexps: []

arlexicons: ['ع']

enlexicons: ['G']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
