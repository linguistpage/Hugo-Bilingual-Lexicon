---
word: "true"

title: "Corpora"

categories: ['']

tags: ['corpora']

arwords: 'مدونات نصوص'

arexps: []

enwords: ['Corpora']

enexps: []

arlexicons: 'د'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
