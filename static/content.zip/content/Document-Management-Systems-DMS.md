---
word: "true"

title: "Document Management Systems-DMS"

categories: ['']

tags: ['Document', 'Management', 'Systems', 'DMS']

arwords: 'نُظُم إدارة الوثائق'

arexps: []

enwords: ['Document Management Systems-DMS']

enexps: []

arlexicons: 'ن'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---