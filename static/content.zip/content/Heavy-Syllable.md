---
word: "true"

title: "Heavy Syllable"

categories: ['']

tags: ['heavy', 'syllable']

arwords: 'مقطع ثقيل'

arexps: []

enwords: ['Heavy Syllable']

enexps: []

arlexicons: 'ق'

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
