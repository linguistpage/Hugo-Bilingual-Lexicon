---
word: "true"

title: "Application Orientated"

categories: ['General','Software']

tags: ['application', 'orientated']

arwords: 'موجّه نحو التطبيقات'

arexps: []

enwords: ['Application Orientated']

enexps: []

arlexicons: 'و'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
