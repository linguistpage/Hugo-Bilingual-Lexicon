---
word: "true"

title: "Inflectional Morphology"

categories: ['']

tags: ['inflectional', 'morphology']

arwords: 'علم الصرف التصريفي'

arexps: []

enwords: ['Inflectional Morphology']

enexps: []

arlexicons: ['ع']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
