---
word: "true"

title: "Psycholinguistic Theory"

categories: ['']

tags: ['psycholinguistic', 'theory']

arwords: 'نظرية لغوية نفسية'

arexps: []

enwords: ['Psycholinguistic Theory']

enexps: []

arlexicons: 'ن'

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
