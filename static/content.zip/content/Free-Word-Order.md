---
word: "true"

title: "Free Word Order"

categories: ['']

tags: ['free', 'word', 'order']

arwords: 'ترتيب حرّ للكلمات'

arexps: []

enwords: ['Free Word Order']

enexps: []

arlexicons: ['ر']

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
