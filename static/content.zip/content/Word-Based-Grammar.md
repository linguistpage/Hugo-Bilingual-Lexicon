---
word: "true"

title: "Word Based Grammar"

categories: ['']

tags: ['Word', 'Based', 'Grammar']

arwords: 'قواعد تبنى على الكلمة'

arexps: []

enwords: ['Word Based Grammar']

enexps: []

arlexicons: 'ق'

enlexicons: 'W'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---