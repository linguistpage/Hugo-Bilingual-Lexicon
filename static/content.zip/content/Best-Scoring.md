---
word: "true"

title: "Best-Scoring"

categories: ['']

tags: ['best', 'scoring']

arwords: 'أفضل التقاط'

arexps: []

enwords: ['Best-Scoring']

enexps: []

arlexicons: 'أ'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
