---
word: "true"

title: "Topicalizing"

categories: ['']

tags: ['topicalizing']

arwords: 'موضوعة'

arexps: []

enwords: ['Topicalizing']

enexps: []

arlexicons: 'و'

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['The Oxford Handbook of Computational Linguistics']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
