---
word: "true"

title: "Psycholinguistics"

categories: ['']

tags: ['psycholinguistics']

arwords: 'علم اللغة النفسي'

arexps: []

enwords: ['Psycholinguistics']

enexps: []

arlexicons: ['ع']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
