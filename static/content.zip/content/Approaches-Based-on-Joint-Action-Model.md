---
word: "true"

title: "Approaches Based on Joint Action Model"
draft: true
categories: ['Human Language Technologies']

tags: ['approaches', 'based', 'on', 'joint', 'action', 'model']

arwords: 'طرق قائمة على نموذج العمل المشترك'

arexps: []

enwords: 'Approaches Based on Joint Action Model'

enexps: []

arlexicons: 'ط'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['Oxford Guide in Computational Linguistics']

sources: ['المنظمة العربية للترجمة']

slug: ""
---


