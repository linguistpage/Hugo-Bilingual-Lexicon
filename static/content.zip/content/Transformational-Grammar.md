---
word: "true"

title: "Transformational Grammar"

categories: ['']

tags: ['transformational', 'grammar']

arwords: 'نحو تحويلي'

arexps: []

enwords: ['Transformational Grammar']

enexps: []

arlexicons: 'ن'

enlexicons: 'T'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['oxford guide for computational linguistics']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
