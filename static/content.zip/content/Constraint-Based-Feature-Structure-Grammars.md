---
word: "true"

title: "Constraint-Based Feature-Structure Grammars"

categories: ['']

tags: ['constraint', 'based', 'feature', 'structure', 'grammars']

arwords: 'قواعد النحو لتركيبات الخواص المقيّدة'

arexps: []

enwords: ['Constraint-Based Feature-Structure Grammars']

enexps: []

arlexicons: 'ق'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
