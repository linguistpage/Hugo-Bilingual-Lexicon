---
word: "true"

title: "Heuristics"

categories: ['']

tags: ['heuristics']

arwords: 'تجريب'

arexps: []

enwords: ['Heuristics']

enexps: []

arlexicons: ['ج']

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
