---
word: "true"

title: "Robot"

categories: ['']

tags: ['Robot']

arwords: 'الإنسان الآلي'

arexps: []

enwords: ['Robot']

enexps: []

arlexicons: 'أ'

enlexicons: 'R'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---