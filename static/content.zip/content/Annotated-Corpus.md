---
word: "true"

title: "Annotated Corpus"

categories: ['NLP' ,'Corpus Linguistics']

tags: ['annotated', 'corpus']

arwords: 'مدونة لغوية معنونة'

arexps: []

enwords: ['Annotated Corpus']

enexps: []

arlexicons: 'د'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---


بالإمكان تزويد المدونة بمعلومات لغوية إضافية تسمى "التعليق التوضيحي" أو "العنونة". يمكن أن تكون هذه المعلومات ذات طبيعة مختلفة ، مثل التعليق التوضيحي أو الدلالي أو التاريخي. الشكل الأكثر شيوعًا للمدونات المعنونة هو  الموسوم نحويًا.
