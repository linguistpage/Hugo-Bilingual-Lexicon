---
word: "true"

title: "The Egyptian Society of Language Engineering-ESOLE"

categories: ['']

tags: ['The', 'Egyptian', 'Society', 'of', 'Language', 'Engineering', 'ESOLE']

arwords: 'الجمعية المصرية لهندسة اللغة'

arexps: []

enwords: ['The Egyptian Society of Language Engineering-ESOLE']

enexps: []

arlexicons: 'ج'

enlexicons: 'T'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---