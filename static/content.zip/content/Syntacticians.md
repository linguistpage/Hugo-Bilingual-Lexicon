---
word: "true"

title: "Syntacticians"

categories: ['']

tags: ['syntacticians']

arwords: 'نحويون'

arexps: []

enwords: ['Syntacticians']

enexps: []

arlexicons: 'ن'

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
