---
word: "true"

title: "Total Function"

categories: ['']

tags: ['total', 'function']

arwords: 'دالة كليّة'

arexps: []

enwords: ['Total Function']

enexps: []

arlexicons: ['د']

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
