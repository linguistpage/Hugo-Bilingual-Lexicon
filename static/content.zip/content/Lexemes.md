---
word: "true"

title: "Lexemes"

categories: ['']

tags: ['Lexemes']

arwords: 'الوحدات المعجمية'

arexps: []

enwords: ['Lexemes']

enexps: []

arlexicons: 'و'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---