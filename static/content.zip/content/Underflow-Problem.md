---
word: "true"

title: "Underflow Problem"

categories: ['']

tags: ['underflow', 'problem']

arwords: 'مشكلة صغر النتائج'

arexps: []

enwords: ['Underflow Problem']

enexps: []

arlexicons: 'ش'

enlexicons: 'U'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['oxford guide for computational linguistics']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
