---
word: "true"

title: "Bit Vector"

categories: 'Computer Science'

tags: ['bit', 'vector']

arwords: 'مصفوفة بتّات'

arexps: []

enwords: 'Bit Vector'

enexps: []

arlexicons: 'ص'

enlexicons: 'B'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: 'دليل أكسفورد في السانيات الحاسوبية'

sources: ['المنظمة العربية للترجمة']

slug: ""
---

هي بنية بيانات مصفوفة تخزن البتات بشكل مضغوط. يمكن استخدامه لتنفيذ بنية بيانات مجموعة بسيطة. تعد مصفوفة البت فعالة في استغلال التوازي على مستوى البت في الأجهزة لأداء العمليات بسرعة.