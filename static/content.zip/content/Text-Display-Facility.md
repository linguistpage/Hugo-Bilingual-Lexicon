---
word: "true"

title: "Text Display Facility"

categories: ['']

tags: ['text', 'display', 'facility']

arwords: 'وسيلة لعرض النصوص'

arexps: []

enwords: ['Text Display Facility']

enexps: []

arlexicons: 'و'

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
