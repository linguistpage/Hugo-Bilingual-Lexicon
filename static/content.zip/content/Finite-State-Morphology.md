---
word: "true"

title: "Finite-State Morphology"

categories: ['']

tags: ['finite', 'state', 'morphology']

arwords: 'علم الصرف المحدود الحالة'

arexps: []

enwords: ['Finite-State Morphology']

enexps: []

arlexicons: 'ع'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
