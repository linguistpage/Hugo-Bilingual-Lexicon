---
word: "true"

title: "Left Recursive"

categories: ['']

tags: ['left', 'recursive']

arwords: 'مكرّر من اليسار'

arexps: []

enwords: ['Left Recursive']

enexps: []

arlexicons: ['ك']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
