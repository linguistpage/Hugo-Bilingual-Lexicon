---
word: "true"

title: "Nondeterminism"

categories: ['']

tags: ['nondeterminism']

arwords: 'لا قطعية'

arexps: []

enwords: ['Nondeterminism']

enexps: []

arlexicons: ['ل']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
