---
word: "true"

title: "Deep Structure"

categories: ['NLP']

tags: ['deep', 'structure']

arwords: 'البنية العميقة'
arwords2: 'تركيب معمّق'

arexps: []

enwords: ['Deep Structure']

enexps: []

arlexicons: 'ب'
arlexicons2: 'ر'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية','مقدمة في حوسبة اللغة العربية']

sources: ['المنظمة العربية للترجمة','مركز الملك عبد الله لخدمة اللغة العربية']

slug: ""
---
