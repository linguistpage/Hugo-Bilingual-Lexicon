---
word: "true"

title: "Branching Node"

categories: ['']

tags: ['branching', 'node']

arwords: 'عقدة متفرّعة'

arexps: []

enwords: ['Branching Node']

enexps: []

arlexicons: 'ع'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
