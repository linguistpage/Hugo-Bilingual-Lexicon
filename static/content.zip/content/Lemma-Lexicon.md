---
word: "true"

title: "Lemma Lexicon"

categories: ['']

tags: ['lemma', 'lexicon']

arwords: 'معجم تصريفات'

arexps: []

enwords: ['Lemma Lexicon']

enexps: []

arlexicons: ['ع']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
