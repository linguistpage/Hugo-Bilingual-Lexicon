---
word: "true"

title: "Focus"

categories: ['']

tags: ['focus']

arwords: 'تركيز'

arexps: []

enwords: ['Focus']

enexps: []

arlexicons: ['ر']

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
