---
word: "true"

title: "Finite-State Methods"

categories: ['']

tags: ['finite', 'state', 'methods']

arwords: 'طريقة محدودة الحالة'

arexps: []

enwords: ['Finite-State Methods']

enexps: []

arlexicons: 'ط'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
