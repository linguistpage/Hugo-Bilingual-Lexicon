---
word: "true"

title: "Noun Phrase-NP"

categories: ['']

tags: ['noun', 'phrase', 'np']

arwords: 'عبارة'
arwords2: 'مركب اسمي'
arwords3: 'جملة اسمية'

arexps: []

enwords: ['Noun Phrase-NP']

enexps: []

arlexicons: 'ع'
arlexicons2: 'ر'
arlexicons3: 'ج'

enlexicons: 'N'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
