---
word: "true"

title: "Diacritics"

categories: ['']

tags: ['diacritics']

arwords: 'علامات'
arwords2: 'حركات'

arexps: []

enwords: ['Diacritics']

enexps: []

arlexicons: 
- 'ع'
- 'ح'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
