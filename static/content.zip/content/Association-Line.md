---
word: "true"

title: "Association Line"

categories: ['']

tags: ['association', 'line']

arwords: 'خطّ ربط'

arexps: []

enwords: ['Association Line']

enexps: []

arlexicons: 'خ'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
