---
word: "true"

title: "Brute-Force"

categories: ['']

tags: ['Brute', 'force']

arwords: 'القوة الحاسوبية المحضة'

arexps: []

enwords: ['Brute-Force']

enexps: []

arlexicons: 'ق'

enlexicons: 'B'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---