---
word: "true"

title: "Stress Shift"

categories: ['']

tags: ['stress', 'shift']

arwords: 'تحوّل في النبرة'

arexps: []

enwords: ['Stress Shift']

enexps: []

arlexicons: ['ح']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
