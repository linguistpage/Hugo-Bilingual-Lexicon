---
word: "true"

title: "Attribute-Value"

categories: ['']

tags: ['attribute', 'value']

arwords: 'قيمة رمزية'

arexps: []

enwords: ['Attribute-Value']

enexps: []

arlexicons: 'ق'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
