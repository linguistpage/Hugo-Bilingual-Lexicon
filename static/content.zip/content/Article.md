---
word: "true"

title: "Article"

categories: ['Linguistics']

tags: ['article']

arwords: 'أداة تعريف أو تنكير'

arexps: []

enwords: ['Article']

enexps: []

arlexicons: 'أ'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
