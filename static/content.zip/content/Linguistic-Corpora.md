---
word: "true"

title: "Linguistic Corpora"

categories: ['']

tags: ['Linguistic', 'Corpora']

arwords: 'المدونات اللغوية'

arexps: []

enwords: ['Linguistic Corpora']

enexps: []

arlexicons: 'د'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---