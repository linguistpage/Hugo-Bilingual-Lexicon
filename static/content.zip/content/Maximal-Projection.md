---
word: "true"

title: "Maximal Projection"

categories: ['']

tags: ['Maximal', 'Projection']

arwords: 'الإسقاط الأقصى'

arexps: []

enwords: ['Maximal Projection']

enexps: []

arlexicons: 'س'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---