---
word: "true"

title: "Speech-to-Speech Translation"

categories: ['']

tags: ['Speech', 'to', 'Speech', 'Translation']

arwords: 'الترجمة الشفهية الآلية'

arexps: []

enwords: ['Speech-to-Speech Translation']

enexps: []

arlexicons: 'ت'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---