---
word: "true"

title: "Function Words"

categories: ['']

tags: ['Function', 'Words']

arwords: 'الكلمات الوظيفية'

arexps: []

enwords: ['Function Words']

enexps: []

arlexicons: 'ك'

enlexicons: 'F'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---