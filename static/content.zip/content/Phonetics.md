---
word: "true"

title: "Phonetics"

categories: ['']

tags: ['Phonetics']

arwords: 'علم الصوتيات'

arexps: []

enwords: ['Phonetics']

enexps: []

arlexicons: 'ع'

enlexicons: 'P'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---