---
word: "true"

title: "Invariant Moments"

categories: ['']

tags: ['Invariant', 'Moments']

arwords: 'العُزُوم القياسية اللامتغيرة'

arexps: []

enwords: ['Invariant Moments']

enexps: []

arlexicons: 'ع'

enlexicons: 'I'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---