---
word: "true"

title: "Intonational Phrase"

categories: ['']

tags: ['intonational', 'phrase']

arwords: 'وحدة تنغيمية'

arexps: []

enwords: ['Intonational Phrase']

enexps: []

arlexicons: 'و'

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
