---
word: "true"

title: "dB Sound Pressure LeveldBspl"

categories: ['']

tags: ['dB', 'Sound', 'Pressure', 'LeveldBspl']

arwords: 'ديسيبل ضغط الصوت'

arexps: []

enwords: ['dB Sound Pressure LeveldBspl']

enexps: []

arlexicons: 'د'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---