---
word: "true"

title: "Extraction"

categories: ['']

tags: ['Extraction']

arwords: 'الاستخلاص'

arexps: []

enwords: ['Extraction']

enexps: []

arlexicons: 'خ'

enlexicons: 'E'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---