---
word: "true"

title: "Audio and Video Search"

categories: ['']

tags: ['Audio', 'and', 'Video', 'Search']

arwords: 'البحث في الصوتيات والمرئيات'

arexps: []

enwords: ['Audio and Video Search']

enexps: []

arlexicons: 'ب'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---