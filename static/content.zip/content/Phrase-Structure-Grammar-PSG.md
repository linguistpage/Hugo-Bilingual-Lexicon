---
word: "true"

title: "Phrase-Structure Grammar-PSG"

categories: ['']

tags: ['phrase', 'structure', 'grammar', 'psg']

arwords: 'قواعد نحوية لتركيب العبارات'
arwords2: 'قواعد التركيب العباري'
arwords3: 'قواعد لغة العبارات المركّبة'

arexps: []

enwords: ['Phrase-Structure Grammar-PSG']

enexps: []

arlexicons: 'ق'

enlexicons: 'P'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
