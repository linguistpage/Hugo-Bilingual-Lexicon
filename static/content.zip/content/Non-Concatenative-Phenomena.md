---
word: "true"

title: "Non-Concatenative Phenomena"

categories: ['']

tags: ['non', 'concatenative', 'phenomena']

arwords: 'ظواهر التقطّع'

arexps: []

enwords: ['Non-Concatenative Phenomena']

enexps: []

arlexicons: ['ظ']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
