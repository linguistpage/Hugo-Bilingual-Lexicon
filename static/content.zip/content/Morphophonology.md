---
word: "true"

title: "Morphophonology"

categories: ['']

tags: ['morphophonology']

arwords: 'علم اﻷصوات الصرفي'

arexps: []

enwords: ['Morphophonology']

enexps: []

arlexicons: ['ع']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
