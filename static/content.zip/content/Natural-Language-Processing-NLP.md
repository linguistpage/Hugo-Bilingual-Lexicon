---
word: "true"

title: "Natural Language Processing-NLP"

categories: ['']

tags: ['Natural', 'Language', 'Processing', 'NLP']

arwords: 'معالجة اللغات الطبيعية'

arexps: []

enwords: ['Natural Language Processing-NLP']

enexps: []

arlexicons: 'ع'

enlexicons: 'N'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---