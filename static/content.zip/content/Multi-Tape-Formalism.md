---
word: "true"

title: "Multi-Tape Formalism"

categories: ['']

tags: ['multi', 'tape', 'formalism']

arwords: 'صيغة متعددة اﻷشرطة'

arexps: []

enwords: ['Multi-Tape Formalism']

enexps: []

arlexicons: ['ص']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
