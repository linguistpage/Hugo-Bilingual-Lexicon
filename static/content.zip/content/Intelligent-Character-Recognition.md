---
word: "true"

title: "Intelligent Character Recognition"

categories: ['']

tags: ['Intelligent', 'Character', 'Recognition']

arwords: 'التعرف الآني على الحروف'

arexps: []

enwords: ['Intelligent Character Recognition']

enexps: []

arlexicons: 'ع'

enlexicons: 'I'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---