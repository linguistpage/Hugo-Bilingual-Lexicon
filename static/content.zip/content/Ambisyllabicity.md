---
word: "true"

title: "Ambisyllabicity"

categories: ['']

tags: ['ambisyllabicity']

arwords: 'انتماء مزدوج'

arexps: []

enwords: ['Ambisyllabicity']

enexps: []

arlexicons: 'ن'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
