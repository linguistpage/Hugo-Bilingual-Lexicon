---
word: "true"

title: "Lexical Etymology"

categories: ['']

tags: ['Lexical', 'Etymology']

arwords: 'التأثيل المعجمي'

arexps: []

enwords: ['Lexical Etymology']

enexps: []

arlexicons: 'أ'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---