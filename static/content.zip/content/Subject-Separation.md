---
word: "true"

title: "Subject Separation"

categories: ['']

tags: ['Subject', 'Separation']

arwords: 'الفصل بين الموضوعات'

arexps: []

enwords: ['Subject Separation']

enexps: []

arlexicons: 'ف'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---