---
word: "true"

title: "Phonotactics"

categories: ['']

tags: ['phonotactics']

arwords: 'سلسلة الصوت المقبولة'

arexps: []

enwords: ['Phonotactics']

enexps: []

arlexicons: ['س']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
