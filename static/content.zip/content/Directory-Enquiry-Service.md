---
word: "true"

title: "Directory Enquiry Service"

categories: ['']

tags: ['directory', 'enquiry', 'service']

arwords: 'خدمة الاستفسار من الدليل'

arexps: []

enwords: ['Directory Enquiry Service']

enexps: []

arlexicons: 'خ'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
