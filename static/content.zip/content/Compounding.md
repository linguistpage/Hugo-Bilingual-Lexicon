---
word: "true"

title: "Compounding"

categories: ['']

tags: ['compounding']

arwords: 'تركيب'

arexps: []

enwords: ['Compounding']

enexps: []

arlexicons: 'ر'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
