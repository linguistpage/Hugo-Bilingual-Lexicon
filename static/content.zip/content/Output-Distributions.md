---
word: "true"

title: "Output Distributions"

categories: ['']

tags: ['Output', 'Distributions']

arwords: 'نماذج المخرجات'

arexps: []

enwords: ['Output Distributions']

enexps: []

arlexicons: 'ن'

enlexicons: 'O'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---