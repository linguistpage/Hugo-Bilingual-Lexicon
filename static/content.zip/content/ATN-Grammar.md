---
word: "true"

title: "ATN Grammar"

categories: ['']

tags: ['atn', 'grammar']

arwords: 'قواعد النحو لشبكة الانتقال المزيدة'

arexps: []

enwords: ['ATN Grammar']

enexps: []

arlexicons: 'ق'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
