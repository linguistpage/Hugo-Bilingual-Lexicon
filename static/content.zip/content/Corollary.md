---
word: "true"

title: "Corollary"

categories: ['']

tags: ['corollary']

arwords: 'بديهية'

arexps: []

enwords: ['Corollary']

enexps: []

arlexicons: 'ب'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
