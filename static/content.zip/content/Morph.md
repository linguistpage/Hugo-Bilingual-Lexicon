---
word: "true"

title: "Morph"

categories: ['']

tags: ['morph']

arwords: 'مورف'

arexps: []

enwords: ['Morph']

enexps: []

arlexicons: 'م'

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
