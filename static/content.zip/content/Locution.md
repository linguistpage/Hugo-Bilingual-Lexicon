---
word: "true"

title: "Locution"

categories: ['']

tags: ['locution']

arwords: 'كلام'

arexps: []

enwords: ['Locution']

enexps: []

arlexicons: ['ك']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
