---
word: "true"

title: "Isolating Language"

categories: ['']

tags: ['isolating', 'language']

arwords: 'لغة عازلة'

arexps: []

enwords: ['Isolating Language']

enexps: []

arlexicons: ['ل']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
