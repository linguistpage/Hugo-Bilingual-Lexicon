---
word: "true"

title: "Prosodic Hierarchy"

categories: ['']

tags: ['prosodic', 'hierarchy']

arwords: 'ترتيب لحني'

arexps: []

enwords: ['Prosodic Hierarchy']

enexps: []

arlexicons: ['ر']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
