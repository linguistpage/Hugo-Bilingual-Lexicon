---
word: "true"

title: "Vocabulary"

categories: ['']

tags: ['Vocabulary']

arwords: 'حصيلة مفردات'

arexps: []

enwords: ['Vocabulary']

enexps: []

arlexicons: 'ح'

enlexicons: 'V'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---