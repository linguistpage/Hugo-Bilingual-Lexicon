---
word: "true"

title: "Video Search"
enwords: "Video Search"
arwords: "البحث الآلي في المرئيات"
categories : ['Search', 'Information Retrieval', 'Human Language Technologies']
tags : ['video','search']
translators : ['Tarek Oraby']
arlexicons : ['ب']
enlexicons : ['v']
authors : ['Tarek Oraby']
citations: ['N/A']
sources: "N/A"
slug: ""
---