---
word: "true"

title: "Assertives"

categories: ['']

tags: ['assertives']

arwords: 'تأكيدات'

arexps: []

enwords: ['Assertives']

enexps: []

arlexicons: 'أ'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
