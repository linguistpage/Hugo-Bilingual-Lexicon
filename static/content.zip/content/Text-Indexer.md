---
word: "true"

title: "Text Indexer"

categories: ['']

tags: ['Text', 'Indexer']

arwords: 'الفهرسة الآلية'

arexps: []

enwords: ['Text Indexer']

enexps: []

arlexicons: 'ف'

enlexicons: 'T'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---