---
word: "true"

title: "Excitation"

categories: ['']

tags: ['Excitation']

arwords: 'الاستثارة'

arexps: []

enwords: ['Excitation']

enexps: []

arlexicons: 'ث'

enlexicons: 'E'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---