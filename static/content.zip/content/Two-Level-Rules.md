---
word: "true"

title: "Two-Level Rules"

categories: ['']

tags: ['two', 'level', 'rules']

arwords: 'قواعد ثنائية المستوى'

arexps: []

enwords: ['Two-Level Rules']

enexps: []

arlexicons: ['ق']

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
