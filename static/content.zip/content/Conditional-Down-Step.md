---
word: "true"

title: "Conditional Down Step"

categories: ['']

tags: ['conditional', 'down', 'step']

arwords: 'هبوط مشروط'

arexps: []

enwords: ['Conditional Down Step']

enexps: []

arlexicons: 'ه'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
