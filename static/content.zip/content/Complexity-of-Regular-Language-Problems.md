---
word: "true"

title: "Complexity of Regular Language Problems"

categories: ['']

tags: ['complexity', 'of', 'regular', 'language', 'problems']

arwords: 'تعقيد مشاكل اللغات الاعتيادية'

arexps: []

enwords: ['Complexity of Regular Language Problems']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
