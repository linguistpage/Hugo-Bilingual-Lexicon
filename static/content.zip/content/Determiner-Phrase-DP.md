---
word: "true"

title: "Determiner Phrase-DP"

categories: ['']

tags: ['Determiner', 'Phrase', 'DP']

arwords: 'عبارة تحديدية'

arexps: []

enwords: ['Determiner Phrase-DP']

enexps: []

arlexicons: 'ع'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---