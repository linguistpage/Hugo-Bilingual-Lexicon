---
word: "true"

title: "Definite-Clause"

categories: ['']

tags: ['definite', 'clause']

arwords: 'شبه جملة معرّفة'

arexps: []

enwords: ['Definite-Clause']

enexps: []

arlexicons: 'ش'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
