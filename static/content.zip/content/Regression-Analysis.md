---
word: "true"

title: "Regression Analysis"

categories: ['']

tags: ['Regression', 'Analysis']

arwords: 'تحليل الانحدار'

arexps: []

enwords: ['Regression Analysis']

enexps: []

arlexicons: 'ح'

enlexicons: 'R'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---