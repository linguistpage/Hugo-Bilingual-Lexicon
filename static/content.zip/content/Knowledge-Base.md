---
word: "true"

title: "Knowledge Base"

categories: ['']

tags: ['knowledge', 'base']

arwords: 'قاعدة معرفيّة'

arexps: []

enwords: ['Knowledge Base']

enexps: []

arlexicons: ['ق']

enlexicons: ['K']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
