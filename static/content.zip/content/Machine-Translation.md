---
word: "true"

title: "Machine Translation"

categories: ['']

tags: ['Machine', 'Translation']

arwords: 'الترجمة الآلية'

arexps: []

enwords: ['Machine Translation']

enexps: []

arlexicons: 'ت'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---