---
word: "true"

title: "Complexity"

categories: ['']

tags: ['complexity']

arwords: 'تعقيد'

arexps: []

enwords: ['Complexity']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
