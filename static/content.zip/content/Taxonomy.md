---
word: "true"

title: "Taxonomy"

categories: ['']

tags: ['Taxonomy']

arwords: 'التصنيف الهرمي'

arexps: []

enwords: ['Taxonomy']

enexps: []

arlexicons: 'ص'

enlexicons: 'T'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---