---
word: "true"

title: "Attribute-Value Matrices"

categories: ['Mathematics']

tags: ['attribute', 'value', 'matrices']

arwords: 'مصفوفات القيم الرمزية'

arexps: []

enwords: ['Attribute-Value Matrices']

enexps: []

arlexicons: 'ص'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
