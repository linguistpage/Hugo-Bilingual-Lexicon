---
word: "true"

title: "Computational Phonology"

categories: ['']

tags: ['computational', 'phonology']

arwords: 'علم اﻷصوات الحاسوبي'

arexps: []

enwords: ['Computational Phonology']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
