---
word: "true"

title: "Digital Image"

categories: ['']

tags: ['Digital', 'Image']

arwords: 'صورة رقمية'

arexps: []

enwords: ['Digital Image']

enexps: []

arlexicons: 'ص'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---