---
word: "true"

title: "Semantic Checker"

categories: ['']

tags: ['Semantic', 'Checker']

arwords: 'المدقق الدلالي'

arexps: []

enwords: ['Semantic Checker']

enexps: []

arlexicons: 'د'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---