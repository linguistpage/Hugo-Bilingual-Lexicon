---
word: "true"

title: "Accepting"

categories: ['']

tags: ['accepting']

arwords: 'قابل'

arexps: []

enwords: ['Accepting']

enexps: []

arlexicons: 'ق'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
