---
word: "true"

title: "Discourse Integration"

categories: ['']

tags: ['Discourse', 'Integration']

arwords: 'الترابط الخطابي'

arexps: []

enwords: ['Discourse Integration']

enexps: []

arlexicons: 'ر'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---