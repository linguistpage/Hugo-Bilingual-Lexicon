---
word: "true"

title: "Semantic Analysis"

categories: ['']

tags: ['Semantic', 'Analysis']

arwords: 'التحليل الدِّلالي'

arexps: []

enwords: ['Semantic Analysis']

enexps: []

arlexicons: 'ح'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---