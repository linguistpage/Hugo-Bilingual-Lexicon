---
word: "true"

title: "Grammatical Functions"

categories: ['']

tags: ['Grammatical', 'Functions']

arwords: 'المعاني الوظيفية'

arexps: []

enwords: ['Grammatical Functions']

enexps: []

arlexicons: 'ع'

enlexicons: 'G'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---