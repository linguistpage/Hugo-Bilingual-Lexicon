---
word: "true"

title: "The Oxford Text Archive"

categories: ['']

tags: ['the', 'oxford', 'text', 'archive']

arwords: 'أرشيف أكسفورد للنصوص'

arexps: []

enwords: ['The Oxford Text Archive']

enexps: []

arlexicons: ['أ']

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
