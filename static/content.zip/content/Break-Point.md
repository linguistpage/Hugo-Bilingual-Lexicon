---
word: "true"

title: "Break Point"

categories: ['']

tags: ['break', 'point']

arwords: 'نقطة انكسار'

arexps: []

enwords: ['Break Point']

enexps: []

arlexicons: 'ن'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
