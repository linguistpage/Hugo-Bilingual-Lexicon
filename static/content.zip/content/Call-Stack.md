---
word: "true"

title: "Call Stack"

categories: ['']

tags: ['call', 'stack']

arwords: 'مكدس طلب'

arexps: []

enwords: ['Call Stack']

enexps: []

arlexicons: 'ك'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
