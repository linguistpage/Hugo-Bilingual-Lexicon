---
word: "true"

title: "Derivation Tree"

categories: ['']

tags: ['derivation', 'tree']

arwords: 'شجرة اشتقاق'

arexps: []

enwords: ['Derivation Tree']

enexps: []

arlexicons: 'ش'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
