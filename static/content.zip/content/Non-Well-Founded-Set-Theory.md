---
word: "true"

title: "Non-Well-Founded Set Theory"

categories: ['']

tags: ['non', 'well', 'founded', 'set', 'theory']

arwords: 'نظرية المجموعات الناقصة البنية'

arexps: []

enwords: ['Non-Well-Founded Set Theory']

enexps: []

arlexicons: 'ن'

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
