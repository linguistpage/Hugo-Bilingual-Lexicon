---
word: "true"

title: "Linear Bound"

categories: ['']

tags: ['linear', 'bound']

arwords: 'حدّ خطي'

arexps: []

enwords: ['Linear Bound']

enexps: []

arlexicons: ['ح']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
