---
word: "true"

title: "Umlaut"

categories: ['']

tags: ['umlaut']

arwords: 'علامة التشكيل اﻷوملوت'

arexps: []

enwords: ['Umlaut']

enexps: []

arlexicons: ['ع']

enlexicons: ['U']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
