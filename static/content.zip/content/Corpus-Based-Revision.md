---
word: "true"

title: "Corpus-Based Revision"

categories: ['']

tags: ['corpus', 'based', 'revision']

arwords: 'مراجعة مستندة على المدونة'

arexps: []

enwords: ['Corpus-Based Revision']

enexps: []

arlexicons: 'ر'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
