---
word: "true"

title: "Generalizability"

categories: ['']

tags: ['generalizability']

arwords: 'تعميم'

arexps: []

enwords: ['Generalizability']

enexps: []

arlexicons: ['ع']

enlexicons: ['G']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
