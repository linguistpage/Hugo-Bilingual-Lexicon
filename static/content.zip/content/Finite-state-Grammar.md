---
word: "true"

title: "Finite-state Grammar"

categories: ['']

tags: ['finite', 'state', 'grammar']

arwords: 'قواعد لغة محدودة الحالة'

arexps: []

enwords: ['Finite-state Grammar']

enexps: []

arlexicons: 'ق'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
