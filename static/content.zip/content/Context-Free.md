---
word: "true"

title: "Context-Free"

categories: ['']

tags: ['context', 'free']

arwords: 'متحرّر من السياق'

arexps: []

enwords: ['Context-Free']

enexps: []

arlexicons: 'ح'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
