---
word: "true"

title: "Decision Problem"

categories: ['']

tags: ['decision', 'problem']

arwords: 'مشكلة قرار'

arexps: []

enwords: ['Decision Problem']

enexps: []

arlexicons: 'ش'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
