---
word: "true"

title: "Monomorpheme"

categories: ['']

tags: ['monomorpheme']

arwords: 'مورفيم مصغّر'

arexps: []

enwords: ['Monomorpheme']

enexps: []

arlexicons: 'م'

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
