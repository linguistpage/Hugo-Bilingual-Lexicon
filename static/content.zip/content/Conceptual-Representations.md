---
word: "true"

title: "Conceptual Representations"

categories: ['']

tags: ['conceptual', 'representations']

arwords: 'تمثيلات المفهومية'

arexps: []

enwords: ['Conceptual Representations']

enexps: []

arlexicons: 'م'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
