---
word: "true"

title: "Sliding Window"

categories: ['']

tags: ['Sliding', 'Window']

arwords: 'نافذة منزلقة'

arexps: []

enwords: ['Sliding Window']

enexps: []

arlexicons: 'ن'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---