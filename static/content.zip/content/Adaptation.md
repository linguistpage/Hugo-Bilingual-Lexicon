---
word: "true"

title: "Adaptation"

categories: ['']

tags: ['adaptation']

arwords: 'التكيّف'

arexps: []

enwords: ['Adaptation']

enexps: []

arlexicons: 'ك'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---