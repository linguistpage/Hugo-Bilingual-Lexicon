---
word: "true"

title: "Decision Tree"

categories: ['']

tags: ['Decision', 'Tree']

arwords: 'شجرة القرار'

arexps: []

enwords: ['Decision Tree']

enexps: []

arlexicons: 'ش'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---