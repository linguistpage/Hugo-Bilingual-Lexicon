---
word: "true"

title: "Machine Tractable"

categories: ['']

tags: ['machine', 'tractable']

arwords: 'قابل للمعالجة بواسطة الحاسوب'

arexps: []

enwords: ['Machine Tractable']

enexps: []

arlexicons: ['ق']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
