---
word: "true"

title: "Perlocutionary Effect"

categories: ['']

tags: ['perlocutionary', 'effect']

arwords: 'تأثير فعلي'

arexps: []

enwords: ['Perlocutionary Effect']

enexps: []

arlexicons: ['أ']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
