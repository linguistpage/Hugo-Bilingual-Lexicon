---
word: "true"

title: "Mean Vector"

categories: ['']

tags: ['Mean', 'Vector']

arwords: 'متجه المتوسط'

arexps: []

enwords: ['Mean Vector']

enexps: []

arlexicons: 'و'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---