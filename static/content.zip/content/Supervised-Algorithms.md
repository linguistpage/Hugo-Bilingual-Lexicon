---
word: "true"

title: "Supervised Algorithms"

categories: ['']

tags: ['Supervised', 'Algorithms']

arwords: 'الخوارزميات اﻹشرافية'

arexps: []

enwords: ['Supervised Algorithms']

enexps: []

arlexicons: 'خ'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---