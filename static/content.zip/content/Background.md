---
word: "true"

title: "Background"
draft: true
categories: ['']

tags: ['Background']

arwords: 'الخلفية'

arexps: []

enwords: ['Background']

enexps: []

arlexicons: 'خ'

enlexicons: 'B'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---