---
word: "true"

title: "Monotonic Increasing"

categories: ['']

tags: ['monotonic', 'increasing']

arwords: 'زيادة مستمرة'

arexps: []

enwords: ['Monotonic Increasing']

enexps: []

arlexicons: ['ز']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
