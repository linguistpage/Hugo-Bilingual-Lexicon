---
word: "true"

title: "Domain Plan"

categories: ['']

tags: ['domain', 'plan']

arwords: 'خطة المجال'

arexps: []

enwords: ['Domain Plan']

enexps: []

arlexicons: 'خ'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
