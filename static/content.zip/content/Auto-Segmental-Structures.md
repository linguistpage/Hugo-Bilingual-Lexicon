---
word: "true"

title: "AutoSegmental Structures"

categories: ['Linguistics']

tags: ['linguistics','auto', 'segmental', 'structures']

arwords: 'تركيبات المقاطع الصوتية'

arexps: []

enwords: ['Auto Segmental Structures']

enexps: []

arlexicons: 'ر'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
