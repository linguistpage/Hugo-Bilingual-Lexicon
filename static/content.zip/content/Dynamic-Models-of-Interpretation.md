---
word: "true"

title: "Dynamic Models of Interpretation"

categories: ['']

tags: ['dynamic', 'models', 'of', 'interpretation']

arwords: 'نماذج دينامية للتفسير'

arexps: []

enwords: ['Dynamic Models of Interpretation']

enexps: []

arlexicons: 'ن'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
