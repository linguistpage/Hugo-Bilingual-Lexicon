---
word: "true"

title: "Unary Rule"

categories: ['']

tags: ['unary', 'rule']

arwords: 'قاعدة أحادية'

arexps: []

enwords: ['Unary Rule']

enexps: []

arlexicons: ['ق']

enlexicons: ['U']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
