---
word: "true"

title: "Lexicon"

categories: ['']

tags: ['Lexicon']

arwords: 'المعجم'

arexps: []

enwords: ['Lexicon']

enexps: []

arlexicons: 'أ'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---