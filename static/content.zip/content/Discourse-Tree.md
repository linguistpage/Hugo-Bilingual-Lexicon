---
word: "true"

title: "Discourse Tree"

categories: ['']

tags: ['discourse', 'tree']

arwords: 'شجرة خطاب'

arexps: []

enwords: ['Discourse Tree']

enexps: []

arlexicons: 'ش'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
