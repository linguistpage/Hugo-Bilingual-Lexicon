---
word: "true"

title: "Concession"

categories: ['']

tags: ['concession']

arwords: 'تنازل'

arexps: []

enwords: ['Concession']

enexps: []

arlexicons: 'ن'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
