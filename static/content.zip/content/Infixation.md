---
word: "true"

title: "Infixation"

categories: ['']

tags: ['infixation']

arwords: 'زوائد وسطية'

arexps: []

enwords: ['Infixation']

enexps: []

arlexicons: ['ز']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
