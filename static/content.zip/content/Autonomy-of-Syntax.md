---
word: "true"

title: "Autonomy of Syntax"

categories: ['']

tags: ['Autonomy', 'of', 'Syntax']

arwords: 'استقلالية النحو'

arexps: []

enwords: ['Autonomy of Syntax']

enexps: []

arlexicons: 'ق'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---