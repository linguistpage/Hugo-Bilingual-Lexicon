---
word: "true"

title: "No-Crossing Constraint"

categories: ['']

tags: ['no', 'crossing', 'constraint']

arwords: 'قيد عدم التقاطع'

arexps: []

enwords: ['No-Crossing Constraint']

enexps: []

arlexicons: ['ق']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
