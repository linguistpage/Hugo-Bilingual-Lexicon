---
word: "true"

title: "Free Morph"

categories: ['']

tags: ['free', 'morph']

arwords: 'مورف حر'

arexps: []

enwords: ['Free Morph']

enexps: []

arlexicons: 'م'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
