---
word: "true"

title: "Nominal Case Marking"

categories: ['']

tags: ['nominal', 'case', 'marking']

arwords: 'علامة حالة الرفع'

arexps: []

enwords: ['Nominal Case Marking']

enexps: []

arlexicons: ['ع']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
