---
word: "true"

title: "Non-Disjunctive"

categories: ['']

tags: ['non', 'disjunctive']

arwords: 'غير طباقي'

arexps: []

enwords: ['Non-Disjunctive']

enexps: []

arlexicons: ['غ']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
