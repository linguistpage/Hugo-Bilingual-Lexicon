---
word: "true"

title: "Perlocutionary Component"

categories: ['']

tags: ['perlocutionary', 'component']

arwords: 'مكوّن فعلي'

arexps: []

enwords: ['Perlocutionary Component']

enexps: []

arlexicons: 'ك'

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
