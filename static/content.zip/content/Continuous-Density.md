---
word: "true"

title: "Continuous Density"

categories: ['']

tags: ['Continuous', 'Density']

arwords: 'كثافة متصلة'

arexps: []

enwords: ['Continuous Density']

enexps: []

arlexicons: 'ك'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---