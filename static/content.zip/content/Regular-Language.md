---
word: "true"

title: "Regular Language"

categories: ['']

tags: ['regular', 'language']

arwords: 'لغة عادية'

arexps: []

enwords: ['Regular Language']

enexps: []

arlexicons: ['ل']

enlexicons: ['R']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
