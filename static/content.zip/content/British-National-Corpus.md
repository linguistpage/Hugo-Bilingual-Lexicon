---
word: "true"

title: "British National Corpus"

categories: ['']

tags: ['british', 'national', 'corpus']

arwords: 'المدونة الوطنية للغة اﻹنجليزية'

arexps: []

enwords: ['British National Corpus']

enexps: []

arlexicons: 'د'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
