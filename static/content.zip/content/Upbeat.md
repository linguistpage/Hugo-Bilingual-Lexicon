---
word: "true"

title: "Upbeat"

categories: ['']

tags: ['upbeat']

arwords: 'صعود'

arexps: []

enwords: ['Upbeat']

enexps: []

arlexicons: 'ص'

enlexicons: ['U']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
