---
word: "true"

title: "Computational Semantics"

categories: ['']

tags: ['computational', 'semantics']

arwords: 'علم الدلالة الحاسوبي'

arexps: []

enwords: ['Computational Semantics']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
