---
word: "true"

title: "Interactive Analyzer-IAN"

categories: ['']

tags: ['Interactive', 'Analyzer', 'IAN']

arwords: 'المحلل النحوي التفاعلي'

arexps: []

enwords: ['Interactive Analyzer-IAN']

enexps: []

arlexicons: 'ح'

enlexicons: 'I'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---