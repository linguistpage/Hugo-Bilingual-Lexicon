---
word: "true"

title: "Descriptive Adequacy"

categories: ['']

tags: ['Descriptive', 'Adequacy']

arwords: 'معيار كفاءة الوصف'

arexps: []

enwords: ['Descriptive Adequacy']

enexps: []

arlexicons: 'ع'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---