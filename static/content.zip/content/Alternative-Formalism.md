---
word: "true"

title: "Alternative Formalism"
draft: true
categories: ['']

tags: ['Alternative', 'formalism']

arwords: 'صياغة بديلة'

arexps: []

enwords: ['Alternative Formalism']

enexps: []

arlexicons: 'ص'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
