---
word: "true"

title: "Context-Free Derivation"

categories: ['']

tags: ['context', 'free', 'derivation']

arwords: 'اشتقاق متحرّر من السياق'

arexps: []

enwords: ['Context-Free Derivation']

enexps: []

arlexicons: 'ش'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
