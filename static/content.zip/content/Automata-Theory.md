---
word: "true"

title: "Automata Theory"

categories: ''

tags: ['automata', 'theory']

arwords: 'نظرية اﻷجهزة اﻵلية'

arexps: []

enwords: 'Automata Theory'

enexps: []

arlexicons: 'ن'

enlexicons: 'A'

authors: 'Ruqayya Roshdy'

translators: 'Tarek Ibrahim'

citations: 'دليل أكسفورد في السانيات الحاسوبية'

sources: 'المنظمة العربية للترجمة'

slug: ""
---
