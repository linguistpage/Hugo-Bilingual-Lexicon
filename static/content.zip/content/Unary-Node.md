---
word: "true"

title: "Unary Node"

categories: ['']

tags: ['unary', 'node']

arwords: 'عقدة أحادية'

arexps: []

enwords: ['Unary Node']

enexps: []

arlexicons: ['ع']

enlexicons: ['U']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
