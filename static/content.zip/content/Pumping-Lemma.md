---
word: "true"

title: "Pumping Lemma"

categories: ['']

tags: ['pumping', 'lemma']

arwords: 'فرضية تمهيدية تكرارية'

arexps: []

enwords: ['Pumping Lemma']

enexps: []

arlexicons: ['ف']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
