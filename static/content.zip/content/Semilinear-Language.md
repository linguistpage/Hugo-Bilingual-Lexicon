---
word: "true"

title: "Semilinear Language"

categories: ['']

tags: ['semilinear', 'language']

arwords: 'لغة شبه خطيّة'

arexps: []

enwords: ['Semilinear Language']

enexps: []

arlexicons: ['ل']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
