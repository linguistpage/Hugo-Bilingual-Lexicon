---
word: "true"

title: "Looping"

categories: ['']

tags: ['looping']

arwords: 'لفّ'

arexps: []

enwords: ['Looping']

enexps: []

arlexicons: ['ل']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
