---
title: "Introduction to Arabic language computing"
artitle: "مقدمة في حوسبة اللغة العربية"
pubhouses: "مركز الملك عبد الله لخدمة اللغة العربية"
authors: ["Mohsen Rashwan","Mohamed Attia","Ahmed Ragheb","Sameh Al-Ansary","Moataz B-Allah AlSaeed"]
book: "true"
languages: "arabic"
layout: "single-books"
pubyears: "2019"
categories: ["NLP", "Arabic"]
tags: ["Introduction","Arabic", "language" ,"computing"]
---

