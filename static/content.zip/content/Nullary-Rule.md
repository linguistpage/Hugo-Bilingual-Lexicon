---
word: "true"

title: "Nullary Rule"

categories: ['']

tags: ['nullary', 'rule']

arwords: 'قاعدة خالية'

arexps: []

enwords: ['Nullary Rule']

enexps: []

arlexicons: ['ق']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
