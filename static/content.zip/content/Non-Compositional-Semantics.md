---
word: "true"

title: "Non-Compositional Semantics"

categories: ['']

tags: ['non', 'compositional', 'semantics']

arwords: 'علم الدلالة اللاتكويني'

arexps: []

enwords: ['Non-Compositional Semantics']

enexps: []

arlexicons: ['ع']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
