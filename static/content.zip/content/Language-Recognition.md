---
word: "true"

title: "Language Recognition"

categories: ['']

tags: ['Language', 'Recognition']

arwords: 'التعرف على اللغة'

arexps: []

enwords: ['Language Recognition']

enexps: []

arlexicons: 'ع'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---