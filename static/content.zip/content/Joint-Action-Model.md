---
word: "true"

title: "Joint Action Model"

categories: ['']

tags: ['joint', 'action', 'model']

arwords: 'نموذج الفعل المشترك'

arexps: []

enwords: ['Joint Action Model']

enexps: []

arlexicons: 'ن'

enlexicons: ['J']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
