---
word: "true"

title: "Parse Tree"

categories: ['']

tags: ['parse', 'tree']

arwords: 'شجرة تحليل'

arexps: []

enwords: ['Parse Tree']

enexps: []

arlexicons: ['ش']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
