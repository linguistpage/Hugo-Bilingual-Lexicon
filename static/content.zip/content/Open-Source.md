---
word: "true"

title: "Open Source"

categories: ['']

tags: ['Open', 'Source']

arwords: 'مفتوح المصدر'

arexps: []

enwords: ['Open Source']

enexps: []

arlexicons: 'ف'

enlexicons: 'O'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---