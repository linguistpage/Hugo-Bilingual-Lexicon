---
word: "true"

title: "Hard-Coded"

categories: ['']

tags: ['hard', 'coded']

arwords: 'مدخل مباشرة في شفرة البرنامج'

arexps: []

enwords: ['Hard-Coded']

enexps: []

arlexicons: ['د']

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
