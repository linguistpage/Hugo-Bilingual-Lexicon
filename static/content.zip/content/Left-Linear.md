---
word: "true"

title: "Left-Linear"

categories: ['']

tags: ['left', 'linear']

arwords: 'خطي على اليسار'

arexps: []

enwords: ['Left-Linear']

enexps: []

arlexicons: ['خ']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
