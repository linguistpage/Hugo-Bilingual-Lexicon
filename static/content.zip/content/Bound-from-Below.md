---
word: "true"

title: "Bound from Below"

categories: ['']

tags: ['bound', 'from', 'below']

arwords: 'محدّد من اﻷسفل'

arexps: []

enwords: ['Bound from Below']

enexps: []

arlexicons: 'ح'

enlexicons: ['B']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
