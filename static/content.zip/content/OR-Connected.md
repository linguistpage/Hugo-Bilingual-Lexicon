---
word: "true"

title: "OR-Connected"

categories: ['']

tags: ['or', 'connected']

arwords: 'مربوط بالمعامل المنطقي أو'

arexps: []

enwords: ['OR-Connected']

enexps: []

arlexicons: 'ر'

enlexicons: ['O']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
