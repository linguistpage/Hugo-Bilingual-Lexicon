---
word: "true"

title: "Circumfix"

categories: ['']

tags: ['circumfix']

arwords: 'لاحقة محيطة'

arexps: []

enwords: ['Circumfix']

enexps: []

arlexicons: 'ل'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
