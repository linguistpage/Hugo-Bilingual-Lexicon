---
word: "true"

title: "Monitor Corpus"

categories: ['']

tags: ['monitor', 'corpus']

arwords: 'مدونة رقيبة'

arexps: []

enwords: ['Monitor Corpus']

enexps: []

arlexicons: 'د'

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
