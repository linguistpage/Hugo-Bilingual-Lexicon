---
word: "true"

title: "Computer Aided Pronounciation Learning"

categories: ['NLP']

tags: ['computer','aided', 'computer-aided', 'pronounciation', 'learning']

arwords: 'تعلم النطق بمساعدة الحاسوب'

arexps: []

enwords: ['Computer Aided Pronounciation Learning']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Oraby']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---