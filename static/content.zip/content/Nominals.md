---
word: "true"

title: "Nominals"

categories: ['']

tags: ['nominals']

arwords: 'اسميات'

arexps: []

enwords: ['Nominals']

enexps: []

arlexicons: ['أ']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
