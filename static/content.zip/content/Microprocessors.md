---
word: "true"

title: "Microprocessors"

categories: ['']

tags: ['Microprocessors']

arwords: 'المعالجات الدقيقة'

arexps: []

enwords: ['Microprocessors']

enexps: []

arlexicons: 'ع'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---