---
word: "true"

title: "Unvoiced"

categories: ['']

tags: ['unvoiced']

arwords: 'مهموس'

arexps: []

enwords: ['Unvoiced']

enexps: []

arlexicons: 'هـ'

enlexicons: ['U']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['oxford guide for computational linguistics']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
