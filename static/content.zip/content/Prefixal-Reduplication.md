---
word: "true"

title: "Prefixal Reduplication"

categories: ['']

tags: ['prefixal', 'reduplication']

arwords: 'تضعيف أمامي'

arexps: []

enwords: ['Prefixal Reduplication']

enexps: []

arlexicons: ['ض']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
