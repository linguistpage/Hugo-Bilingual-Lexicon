---
word: "true"

title: "Situation Theory"

categories: ['']

tags: ['situation', 'theory']

arwords: 'نظرية الحالة'

arexps: []

enwords: ['Situation Theory']

enexps: []

arlexicons: 'ن'

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
