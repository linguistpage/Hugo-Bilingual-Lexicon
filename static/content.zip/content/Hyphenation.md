---
word: "true"

title: "Hyphenation"

categories: ['']

tags: ['hyphenation']

arwords: 'وضع الكشيدة'
arwords2: 'التشريط'

arexps: []

enwords: ['Hyphenation']

enexps: []

arlexicons: 'و'

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
