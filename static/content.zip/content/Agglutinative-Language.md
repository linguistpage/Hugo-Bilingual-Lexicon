---
word: "true"

title: "Agglutinative Language"

categories: ['']

tags: ['agglutinative', 'language']

arwords: 'لغة التصاقية'

arexps: []

enwords: ['Agglutinative Language']

enexps: []

arlexicons: 'ل'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
