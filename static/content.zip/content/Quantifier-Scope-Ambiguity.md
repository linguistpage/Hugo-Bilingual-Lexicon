---
word: "true"

title: "Quantifier Scope Ambiguity"

categories: ['']

tags: ['quantifier', 'scope', 'ambiguity']

arwords: 'غموض نطاق المحدّد الكمي'

arexps: []

enwords: ['Quantifier Scope Ambiguity']

enexps: []

arlexicons: ['غ']

enlexicons: ['Q']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
