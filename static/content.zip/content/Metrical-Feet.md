---
word: "true"

title: "Metrical Feet"

categories: ['']

tags: ['metrical', 'feet']

arwords: 'تفعيلات'

arexps: []

enwords: ['Metrical Feet']

enexps: []

arlexicons: ['ف']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
