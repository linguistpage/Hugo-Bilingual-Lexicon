---
word: "true"

title: "Active Voice"

categories: ['']

tags: ['active', 'voice']

arwords: 'المبني للمعلوم'

arexps: []

enwords: ['Active Voice']

enexps: []

arlexicons: 'ب'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
