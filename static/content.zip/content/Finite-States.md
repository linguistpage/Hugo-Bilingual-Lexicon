---
word: "true"

title: "Finite States"

categories: ['']

tags: ['finite', 'states']

arwords: 'حالات محدودة'

arexps: []

enwords: ['Finite States']

enexps: []

arlexicons: 'ح'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
