---
word: "true"

title: "Degraded Text"

categories: ['']

tags: ['Degraded', 'Text']

arwords: 'نُصوص متدهورة'

arexps: []

enwords: ['Degraded Text']

enexps: []

arlexicons: 'ن'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---