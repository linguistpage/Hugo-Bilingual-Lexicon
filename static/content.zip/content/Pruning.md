---
word: "true"

title: "Pruning"

categories: ['']

tags: ['pruning']

arwords: 'تقليم'

arwords2: 'تشذيب'

arexps: []

enwords: ['Pruning']

enexps: []

arlexicons: 
- 'ق'
- 'ش'

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
