---
word: "true"

title: "Linear Precedence Constraint"

categories: ['']

tags: ['linear', 'precedence', 'constraint']

arwords: 'قيد أسبقية خطية'

arexps: []

enwords: ['Linear Precedence Constraint']

enexps: []

arlexicons: ['ق']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
