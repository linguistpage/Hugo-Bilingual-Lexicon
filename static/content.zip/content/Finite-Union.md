---
word: "true"

title: "Finite Union"

categories: ['']

tags: ['finite', 'union']

arwords: 'اتحاد محدود'

arexps: []

enwords: ['Finite Union']

enexps: []

arlexicons: 'و'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
