---
word: "true"

title: "Capital Letters"

categories: ['']

tags: ['Capital', 'Letters']

arwords: 'حروف كبيرة في الرسم'

arexps: []

enwords: ['Capital Letters']

enexps: []

arlexicons: 'ح'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---