---
word: "true"

title: "Context-Sensitive Grammar"

categories: ['']

tags: ['context', 'sensitive', 'grammar']

arwords: 'قواعد اللغة الحساسة للسياق'

arexps: []

enwords: ['Context-Sensitive Grammar']

enexps: []

arlexicons: 'ق'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
