---
word: "true"

title: "Linearity"

categories: ['']

tags: ['linearity']

arwords: 'خطية'

arexps: []

enwords: ['Linearity']

enexps: []

arlexicons: ['خ']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
