---
word: "true"

title: "Memory Footprint"

categories: ['']

tags: ['memory', 'footprint']

arwords: 'ذاكرة وقت التشغيل'

arexps: []

enwords: ['Memory Footprint']

enexps: []

arlexicons: ['ذ']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
