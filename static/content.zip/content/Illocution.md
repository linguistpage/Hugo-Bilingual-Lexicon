---
word: "true"

title: "Illocution"

categories: ['']

tags: ['illocution']

arwords: 'قصد'

arexps: []

enwords: ['Illocution']

enexps: []

arlexicons: ['ق']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
