---
word: "true"

title: "Dialogue Management"

categories: ['']

tags: ['dialogue', 'management']

arwords: 'إدارة الحوار'

arexps: []

enwords: ['Dialogue Management']

enexps: []

arlexicons: 'أ'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
