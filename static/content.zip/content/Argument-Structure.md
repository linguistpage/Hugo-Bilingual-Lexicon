---
word: "true"

title: "Argument Structure"

categories: ['']

tags: ['argument', 'structure']

arwords: 'تركيب المعنى المساعد'

arexps: []

enwords: ['Argument Structure']

enexps: []

arlexicons: 'ر'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
