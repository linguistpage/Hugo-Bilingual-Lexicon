---
word: "true"

title: "Ghost Word"

categories: ['']

tags: ['ghost', 'word']

arwords: 'كلمة شبحية'

arexps: []

enwords: ['Ghost Word']

enexps: []

arlexicons: ['ك']

enlexicons: ['G']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
