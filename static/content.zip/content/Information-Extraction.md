---
word: "true"

title: "Information Extraction"

categories: ['']

tags: ['Information', 'Extraction']

arwords: 'استخراج المعلومات'

arexps: []

enwords: ['Information Extraction']

enexps: []

arlexicons: 'خ'

enlexicons: 'I'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---