---
word: "true"

title: "Noun Compound"

categories: ['']

tags: ['noun', 'compound']

arwords: 'مركب اسمي'

arexps: []

enwords: ['Noun Compound']

enexps: []

arlexicons: 'ر'

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
