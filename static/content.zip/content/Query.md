---
word: "true"

title: "Query"

categories: ['']

tags: ['Query']

arwords: 'طلب البحث'

arexps: []

enwords: ['Query']

enexps: []

arlexicons: 'ط'

enlexicons: 'Q'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---