---
word: "true"

title: "Treebank Arabic"

categories: ['']

tags: ['Treebank', 'Arabic']

arwords: 'البنك النحوي العربي'

arexps: []

enwords: ['Treebank Arabic']

enexps: []

arlexicons: 'ب'

enlexicons: 'T'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---