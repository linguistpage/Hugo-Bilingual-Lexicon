---
word: "true"

title: "Intractable"

categories: ['']

tags: ['intractable']

arwords: 'صعب الحل'

arexps: []

enwords: ['Intractable']

enexps: []

arlexicons: ['ص']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
