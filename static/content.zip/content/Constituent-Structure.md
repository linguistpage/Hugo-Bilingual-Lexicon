---
word: "true"

title: "Constituent Structure"

categories: ['']

tags: ['constituent', 'structure']

arwords: 'تركيب أساسي'

arexps: []

enwords: ['Constituent Structure']

enexps: []

arlexicons: 'ر'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
