---
word: "true"

title: "Dynamic Programming"

categories: ['']

tags: ['dynamic', 'programming']

arwords: 'برمجة حركية'
arwords2: 'برمجة ديناميكية'

arexps: []

enwords: ['Dynamic Programming']

enexps: []

arlexicons: 'ب'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
