---
word: "true"

title: "Default Pairing"

categories: ['']

tags: ['default', 'pairing']

arwords: 'مزاوجة افتراضية'

arexps: []

enwords: ['Default Pairing']

enexps: []

arlexicons: 'ز'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
