---
word: "true"

title: "Asymptotic Lower Bound"

categories: ['']

tags: ['asymptotic', 'lower', 'bound']

arwords: 'حدّ مقارب أدنى'

arexps: []

enwords: ['Asymptotic Lower Bound']

enexps: []

arlexicons: 'ح'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
