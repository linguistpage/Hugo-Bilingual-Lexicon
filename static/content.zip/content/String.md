---
word: "true"

title: "String"

categories: ['']

tags: ['string']

arwords: 'سلسلة'

arexps: []

enwords: ['String']

enexps: []

arlexicons: ['س']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
