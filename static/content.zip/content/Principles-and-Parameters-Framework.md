---
word: "true"

title: "Principles and Parameters Framework"

categories: ['']

tags: ['principles', 'and', 'parameters', 'framework']

arwords: 'إطار المبادئ والمعاملات'

arexps: []

enwords: ['Principles and Parameters Framework']

enexps: []

arlexicons: ['أ']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
