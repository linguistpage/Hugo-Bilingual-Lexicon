---
word: "true"

title: "Incremental Interpretation"

categories: ['']

tags: ['incremental', 'interpretation']

arwords: 'تفسير تدريجي'

arexps: []

enwords: ['Incremental Interpretation']

enexps: []

arlexicons: ['ف']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
