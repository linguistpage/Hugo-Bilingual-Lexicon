---
word: "true"

title: "Descriptive Questions"

categories: ['']

tags: ['Descriptive', 'Questions']

arwords: 'أسئلة وصفية'

arexps: []

enwords: ['Descriptive Questions']

enexps: []

arlexicons: 'س'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---