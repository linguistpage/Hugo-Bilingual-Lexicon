---
word: "true"

title: "Collocations"

categories: ['']

tags: ['Collocations']

arwords: 'المتلازمات اللفظية'

arexps: []

enwords: ['Collocations']

enexps: []

arlexicons: 'ل'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---