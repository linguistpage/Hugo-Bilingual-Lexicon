---
word: "true"

title: "Ablaut"

categories: ['']

tags: ['ablaut']

arwords: 'أبلوت'

arexps: []

enwords: ['Ablaut']

enexps: []

arlexicons: 'أ'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

draft: true 

slug: ""
---
