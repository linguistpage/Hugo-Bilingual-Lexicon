---
word: "true"

title: "Sentence-S"

categories: ['']

tags: ['Sentence']

arwords: 'الجملة'

arexps: []

enwords: ['Sentence-S']

enexps: []

arlexicons: 'ج'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---