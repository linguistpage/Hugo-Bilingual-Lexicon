---
word: "true"

title: "Cross Lingual Plagiarism Detection-CLPD"

categories: ['']

tags: ['Cross', 'Lingual', 'Plagiarism', 'Detection', 'CLPD']

arwords: 'الكشف عن السرقات الأدبية عن طريق الترجمة'

arexps: []

enwords: ['Cross Lingual Plagiarism Detection-CLPD']

enexps: []

arlexicons: 'ك'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---