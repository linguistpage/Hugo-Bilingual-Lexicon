---
word: "true"

title: "Lexical Analysis"

categories: ['']

tags: ['Lexical', 'Analysis']

arwords: 'التحليل المعجمي'

arexps: []

enwords: ['Lexical Analysis']

enexps: []

arlexicons: 'ح'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---