---
word: "true"

title: "Discourse Representation Structure"

categories: ['']

tags: ['discourse', 'representation', 'structure']

arwords: 'بنية تمثيل الخطاب'

arexps: []

enwords: ['Discourse Representation Structure']

enexps: []

arlexicons: 'ب'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
