---
word: "true"

title: "Spell Checking and Correction"

categories: ['']

tags: ['Spell', 'Checking', 'and', 'Correction']

arwords: 'التدقيق والتصحيح الإملائي'

arexps: []

enwords: ['Spell Checking and Correction']

enexps: []

arlexicons: 'د'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---