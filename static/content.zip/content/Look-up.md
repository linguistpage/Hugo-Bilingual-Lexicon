---
word: "true"

title: "Look-up"

categories: ['']

tags: ['look', 'up']

arwords: 'بحث'

arexps: []

enwords: ['Look-up']

enexps: []

arlexicons: ['ب']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
