---
word: "true"

title: "Computational Morphology"

categories: ['']

tags: ['computational', 'morphology']

arwords: 'علم الصرف الحاسوبي'

arexps: []

enwords: ['Computational Morphology']

enexps: []

arlexicons: 'ع'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
