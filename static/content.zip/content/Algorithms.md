---
word: "true"

title: "Algorithms"

categories: ['']

tags: ['algorithms']

arwords: 'خوارزميات'

arexps: []

enwords: ['Algorithms']

enexps: []

arlexicons: 'خ'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
