---
word: "true"

title: "Finite-State Compiler"

categories: ['']

tags: ['finite', 'state', 'compiler']

arwords: 'مُجمِّع المحدود الحالة'

arexps: []

enwords: ['Finite-State Compiler']

enexps: []

arlexicons: 'ج'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
