---
word: "true"

title: "Domain Knowledge"

categories: ['']

tags: ['domain', 'knowledge']

arwords: 'مجال معرفي'

arexps: []

enwords: ['Domain Knowledge']

enexps: []

arlexicons: 'ج'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
