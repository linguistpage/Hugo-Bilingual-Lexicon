---
word: "true"

title: "Corpus-Based Dictionary"

categories: ['']

tags: ['corpus', 'based', 'dictionary']

arwords: 'قاموس مستند على مدونة لغوية'

arexps: []

enwords: ['Corpus-Based Dictionary']

enexps: []

arlexicons: 'ق'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
