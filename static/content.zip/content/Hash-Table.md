---
word: "true"

title: "Hash Table"

categories: ['']

tags: ['hash', 'table']

arwords: 'جدول الهاش'

arexps: []

enwords: ['Hash Table']

enexps: []

arlexicons: ['ج']

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
