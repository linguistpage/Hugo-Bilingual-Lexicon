---
word: "true"

title: "Derivation Subtree"

categories: ['']

tags: ['derivation', 'subtree']

arwords: 'شجرة اشتقاق فرعية'

arexps: []

enwords: ['Derivation Subtree']

enexps: []

arlexicons: 'ش'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
