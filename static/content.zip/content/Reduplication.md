---
word: "true"

title: "Reduplication"

categories: ['']

tags: ['reduplication']

arwords: 'تضعيف'

arexps: []

enwords: ['Reduplication']

enexps: []

arlexicons: ['ض']

enlexicons: ['R']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
