---
word: "true"

title: "Closed-Class"

categories: ['']

tags: ['closed', 'class']

arwords: 'فئة مغلقة'

arexps: []

enwords: ['Closed-Class']

enexps: []

arlexicons: 'ف'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
