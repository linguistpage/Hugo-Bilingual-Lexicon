---
word: "true"

title: "Classification"

categories: ['']

tags: ['Classification']

arwords: 'تصنيف'

arexps: []

enwords: ['Classification']

enexps: []

arlexicons: 'ص'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---