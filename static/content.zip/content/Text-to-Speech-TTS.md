---
word: "true"

title: "Text to Speech-TTS"

categories: ['']

tags: ['text', 'to', 'speech', 'tts']

arwords: 'تحويل النصوص إلى كلام'

arexps: []

enwords: ['Text to Speech-TTS']

enexps: []

arlexicons: 'ح'

enlexicons: 'T'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
