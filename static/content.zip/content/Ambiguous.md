---
word: "true"

title: "Ambiguous"

categories: ['']

tags: ['ambiguous']

arwords: 'غامض'

arexps: []

enwords: ['Ambiguous']

enexps: []

arlexicons: 'غ'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
