---
word: "true"

title: "Directive"

categories: ['']

tags: ['directive']

arwords: 'أمر'

arexps: []

enwords: ['Directive']

enexps: []

arlexicons: 'أ'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
