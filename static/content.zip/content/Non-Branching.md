---
word: "true"

title: "Non-Branching"

categories: ['']

tags: ['non', 'branching']

arwords: 'عدم التفرّع'

arexps: []

enwords: ['Non-Branching']

enexps: []

arlexicons: ['ع']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
