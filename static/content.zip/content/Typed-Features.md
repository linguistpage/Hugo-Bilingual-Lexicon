---
word: "true"

title: "Typed Features"

categories: ['']

tags: ['typed', 'features']

arwords: 'خواص نوعية'

arexps: []

enwords: ['Typed Features']

enexps: []

arlexicons: ['خ']

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
