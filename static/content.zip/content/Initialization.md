---
word: "true"

title: "Initialization"

categories: ['']

tags: ['initialization']

arwords: 'تهيئة'

arexps: []

enwords: ['Initialization']

enexps: []

arlexicons: ['هـ']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
