---
word: "true"

title: "Linguistically-Motivated"

categories: ['']

tags: ['linguistically', 'motivated']

arwords: 'متحفّز لغوياً'

arexps: []

enwords: ['Linguistically-Motivated']

enexps: []

arlexicons: ['ح']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
