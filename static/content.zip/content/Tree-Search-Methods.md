---
word: "true"

title: "Tree Search Methods"

categories: ['']

tags: ['Tree', 'Search', 'Methods']

arwords: 'أساليب البحث الشجرية'

arexps: []

enwords: ['Tree Search Methods']

enexps: []

arlexicons: 'س'

enlexicons: 'T'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---