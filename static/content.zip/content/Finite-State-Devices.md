---
word: "true"

title: "Finite-State Devices"

categories: ['']

tags: ['finite', 'state', 'devices']

arwords: 'أجهزة الحالات المحدودة'

arexps: []

enwords: ['Finite-State Devices']

enexps: []

arlexicons: 'ج'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
