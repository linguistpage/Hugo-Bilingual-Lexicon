---
word: "true"

title: "Context-Free Recognition"

categories: ['']

tags: ['context', 'free', 'recognition']

arwords: 'تمييز متحرّر من السياق'

arexps: []

enwords: ['Context-Free Recognition']

enexps: []

arlexicons: 'م'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
