---
word: "true"

title: "Artificial Neural Networks"

categories: ['']

tags: ['artificial', 'neural', 'networks']

arwords: 'الشبكات العصبية الاصطناعية'

arexps: []

enwords: ['Artificial Neural Networks']

enexps: []

arlexicons: 'ش'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---