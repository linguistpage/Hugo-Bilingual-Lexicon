---
word: "true"

title: "Adjacency Pairs"

categories: ['']

tags: ['adjacency', 'pairs']

arwords: 'أزواج متجاورة'

arexps: []

enwords: ['Adjacency Pairs']

enexps: []

arlexicons: 'ز'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
