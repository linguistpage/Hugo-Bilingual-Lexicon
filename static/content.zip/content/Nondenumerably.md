---
word: "true"

title: "Nondenumerably"

categories: ['']

tags: ['nondenumerably']

arwords: 'غير معدود'

arexps: []

enwords: ['Nondenumerably']

enexps: []

arlexicons: ['غ']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
