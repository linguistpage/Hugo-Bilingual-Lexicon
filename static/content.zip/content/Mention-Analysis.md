---
word: "true"

title: "Mention Analysis"

categories: ['']

tags: ['Mention', 'Analysis']

arwords: 'تحليل الإلماحات'

arexps: []

enwords: ['Mention Analysis']

enexps: []

arlexicons: 'ح'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---