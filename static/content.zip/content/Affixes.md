---
word: "true"

title: "Affixes"

categories: ['']

tags: ['Affixes']

arwords: 'اللواصق'

arexps: []

enwords: ['Affixes']

enexps: []

arlexicons: 'ل'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---