---
word: "true"

title: "Conversational System"

categories: ['']

tags: ['conversational', 'system']

arwords: 'نظام محادثة'

arexps: []

enwords: ['Conversational System']

enexps: []

arlexicons: 'ن'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
