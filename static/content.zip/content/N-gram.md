---
word: "true"

title: "N-gram"

categories: ['']

tags: ['N', 'gram']

arwords: 'النماذج اللغوية للنَّحو اﻹحصائي'

arexps: []

enwords: ['N-gram']

enexps: []

arlexicons: 'ن'

enlexicons: 'N'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---