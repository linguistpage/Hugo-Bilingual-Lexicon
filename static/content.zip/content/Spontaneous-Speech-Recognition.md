---
word: "true"

title: "Spontaneous Speech Recognition"

categories: ['']

tags: ['Spontaneous', 'Speech', 'Recognition']

arwords: 'التعرف الآلي على حوارات الاجتماعات والمحاضرات'

arexps: []

enwords: ['Spontaneous Speech Recognition']

enexps: []

arlexicons: 'ع'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---