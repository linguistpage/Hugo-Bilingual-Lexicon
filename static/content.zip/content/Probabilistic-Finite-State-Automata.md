---
word: "true"

title: "Probabilistic Finite-State Automata"

categories: ['']

tags: ['probabilistic', 'finite', 'state', 'automata']

arwords: 'أجهزة آلية محدودة الاحتمالية'

arexps: []

enwords: ['Probabilistic Finite-State Automata']

enexps: []

arlexicons: ['ج']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
