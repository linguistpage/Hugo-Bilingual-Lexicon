---
word: "true"

title: "Underspecification Phonology"

categories: ['']

tags: ['underspecification', 'phonology']

arwords: 'علم اﻷصوات الناقص'

arexps: []

enwords: ['Underspecification Phonology']

enexps: []

arlexicons: ['ع']

enlexicons: ['U']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
