---
word: "true"

title: "Relative Clause"

categories: ['']

tags: ['relative', 'clause']

arwords: 'عبارة وصل'

arexps: []

enwords: ['Relative Clause']

enexps: []

arlexicons: ['ع']

enlexicons: ['R']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
