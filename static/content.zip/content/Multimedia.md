---
word: "true"

title: "Multimedia"

categories: ['']

tags: ['Multimedia']

arwords: 'الوسائط المتعددة'

arexps: []

enwords: ['Multimedia']

enexps: []

arlexicons: 'و'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---