---
word: "true"

title: "Metaplan"

categories: ['']

tags: ['metaplan']

arwords: 'خطة تعريفية'

arexps: []

enwords: ['Metaplan']

enexps: []

arlexicons: ['خ']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
