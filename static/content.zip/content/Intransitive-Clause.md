---
word: "true"

title: "Intransitive Clause"

categories: ['']

tags: ['intransitive', 'clause']

arwords: 'عبارة لازمة'

arexps: []

enwords: ['Intransitive Clause']

enexps: []

arlexicons: ['ع']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
