---
word: "true"

title: "Typewritter OCR"
enwords: "TypeWritten Optical Character Recognition"
arwords: "التعرف الآلي على الكلام المطبوع"
categories : ['OCR', 'Information Retrieval']
tags : ['typewritten','OCR','optical','character','recognition']
translators : ['Tarek Oraby']
arlexicons : ['ع']
enlexicons : ['T']
authors : ['Tarek Oraby']
citations: ['N/A']
sources: "N/A"
slug: ""
---