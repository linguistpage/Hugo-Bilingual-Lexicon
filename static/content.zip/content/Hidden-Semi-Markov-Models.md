---
word: "true"

title: "Hidden Semi Markov Models"

categories: ['']

tags: ['Hidden', 'Semi', 'Markov', 'Models']

arwords: 'نماذج شبه-ماركوف المخفِيَّة'

arexps: []

enwords: ['Hidden Semi Markov Models']

enexps: []

arlexicons: 'ن'

enlexicons: 'H'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---