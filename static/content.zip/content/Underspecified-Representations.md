---
word: "true"

title: "Underspecified Representations"

categories: ['']

tags: ['underspecified', 'representations']

arwords: 'تمثيلات ناقصة'

arexps: []

enwords: ['Underspecified Representations']

enexps: []

arlexicons: ['م']

enlexicons: ['U']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
