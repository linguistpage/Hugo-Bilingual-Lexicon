---
word: "true"

title: "Surface Strucutre"

categories: ['']

tags: ['Surface', 'Strucutre']

arwords: 'البنية السطحية'

arexps: []

enwords: ['Surface Strucutre']

enexps: []

arlexicons: 'ب'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---