---
word: "true"

title: "Anaphoric Reference"

categories: ['']

tags: ['anaphoric', 'reference']

arwords: 'إشارة الإحالة النحوية'

arexps: []

enwords: ['Anaphoric Reference']

enexps: []

arlexicons: 'ش'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
