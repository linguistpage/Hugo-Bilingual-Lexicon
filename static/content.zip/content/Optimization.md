---
word: "true"

title: "Optimization"

categories: ['']

tags: ['optimization']

arwords: 'كفاءة قصوى'

arexps: []

enwords: ['Optimization']

enexps: []

arlexicons: ['ك']

enlexicons: ['O']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
