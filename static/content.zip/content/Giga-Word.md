---
word: "true"

title: "Giga Word"

categories: ['']

tags: ['Giga', 'Word']

arwords: 'جيجا وورد'

arexps: []

enwords: ['Giga Word']

enexps: []

arlexicons: 'ج'

enlexicons: 'G'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---