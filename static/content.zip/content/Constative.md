---
word: "true"

title: "Constative"

categories: ['']

tags: ['constative']

arwords: 'خبري'

arexps: []

enwords: ['Constative']

enexps: []

arlexicons: 'خ'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
