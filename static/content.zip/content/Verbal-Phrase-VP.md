---
word: "true"

title: "Verbal Phrase-VP"

categories: ['']

tags: ['Verbal', 'Phrase', 'VP']

arwords: 'مركب فعلي'

arexps: []

enwords: ['Verbal Phrase-VP']

enexps: []

arlexicons: 'ر'

enlexicons: 'V'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---