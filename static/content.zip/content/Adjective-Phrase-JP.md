---
word: "true"

title: "Adjective Phrase-JP"

categories: ['']

tags: ['Adjective', 'Phrase', 'JP']

arwords: 'مركب وصفي'

arexps: []

enwords: ['Adjective Phrase-JP']

enexps: []

arlexicons: 'ر'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---