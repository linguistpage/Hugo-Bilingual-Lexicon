---
word: "true"

title: "Histogram Pruning"

categories: ['']

tags: ['histogram', 'pruning']

arwords: 'تقليم المدرج التكراري'

arexps: []

enwords: ['Histogram Pruning']

enexps: []

arlexicons: ['ق']

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
