---
word: "true"

title: "Enterprise Search"

categories: ['']

tags: ['Enterprise', 'Search']

arwords: 'محركات البحث في الوثائق المؤسسية'

arexps: []

enwords: ['Enterprise Search']

enexps: []

arlexicons: 'ح'

enlexicons: 'E'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---