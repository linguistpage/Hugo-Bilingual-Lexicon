---
word: "true"

title: "Bigram"

categories: ['NLP']

tags: ['Bigram']

arwords: 'زوج من وحدات متتالية'

arexps: []

enwords: ['Bigram']

enexps: []

arlexicons: ''

enlexicons: 'B'

authors: ['Ruqayya Roshdy']

translators: ['Tarek Oraby']

citations: 'Wikipedia'

sources: 'https://en.wikipedia.org/wiki/Bigram'

slug: ""
---

زوج من الوحدات المكتوبة المتتالية مثل الحروف أو المقاطع أو الكلمات.