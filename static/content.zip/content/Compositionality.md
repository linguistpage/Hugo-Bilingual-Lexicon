---
word: "true"

title: "Compositionality"

categories: ['']

tags: ['compositionality']

arwords: 'مبدأ التكوين'

arexps: []

enwords: ['Compositionality']

enexps: []

arlexicons: 'ب'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
