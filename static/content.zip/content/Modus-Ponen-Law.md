---
word: "true"

title: "Modus Ponen Law"

categories: ['']

tags: ['modus', 'ponen', 'law']

arwords: 'قانون القياس الاستثنائي'

arexps: []

enwords: ['Modus Ponen Law']

enexps: []

arlexicons: ['ق']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
