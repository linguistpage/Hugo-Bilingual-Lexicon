---
word: "true"

title: "Property Theory"

categories: ['']

tags: ['property', 'theory']

arwords: 'نظرية الخواص'

arexps: []

enwords: ['Property Theory']

enexps: []

arlexicons: 'ن'

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
