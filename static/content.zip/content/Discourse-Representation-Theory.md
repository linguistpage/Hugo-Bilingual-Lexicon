---
word: "true"

title: "Discourse Representation Theory"

categories: ['']

tags: ['discourse', 'representation', 'theory']

arwords: 'نظرية تمثيل الخطاب الكلاسيكية'
arwords2: 'نظرية تمثيل الخطاب'

arexps: []

enwords: ['Discourse Representation Theory']

enexps: []

arlexicons: 'ن'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
