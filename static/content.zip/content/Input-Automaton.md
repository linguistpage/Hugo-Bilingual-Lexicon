---
word: "true"

title: "Input Automaton"

categories: ['']

tags: ['input', 'automaton']

arwords: 'جهاز ادخال آلي'

arexps: []

enwords: ['Input Automaton']

enexps: []

arlexicons: ['ج']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
