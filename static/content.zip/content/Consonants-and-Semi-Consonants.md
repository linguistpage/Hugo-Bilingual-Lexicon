---
word: "true"

title: "Consonants and Semi Consonants"

categories: ['']

tags: ['Consonants', 'and', 'Semi', 'Consonants']

arwords: 'الصوامت وأشباه الصوامت'

arexps: []

enwords: ['Consonants and Semi Consonants']

enexps: []

arlexicons: 'ص'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---