---
word: "true"

title: "Incremental Search"

categories: ['']

tags: ['incremental', 'search']

arwords: 'بحث تدريجي'

arexps: []

enwords: ['Incremental Search']

enexps: []

arlexicons: ['ب']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
