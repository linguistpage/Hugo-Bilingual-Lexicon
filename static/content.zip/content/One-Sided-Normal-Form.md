---
word: "true"

title: "One-Sided Normal Form"

categories: ['']

tags: ['one', 'sided', 'normal', 'form']

arwords: 'شكل عادي أحادي الجانب'

arexps: []

enwords: ['One-Sided Normal Form']

enexps: []

arlexicons: ['ش']

enlexicons: ['O']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
