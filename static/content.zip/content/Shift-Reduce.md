---
word: "true"

title: "Shift-Reduce"

categories: ['']

tags: ['shift', 'reduce']

arwords: 'تقدّم واختصار'

arexps: []

enwords: ['Shift-Reduce']

enexps: []

arlexicons: ['ق']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
