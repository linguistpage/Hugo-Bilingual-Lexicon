---
word: "true"

title: "Complement-COM"

categories: ['']

tags: ['Complement', 'COM']

arwords: 'المكمل'

arexps: []

enwords: ['Complement-COM']

enexps: []

arlexicons: 'ك'

enlexicons: 'C'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---