---
word: "true"

title: "Dialogue Typology"

categories: ['']

tags: ['dialogue', 'typology']

arwords: 'تصنيف الحوار'

arexps: []

enwords: ['Dialogue Typology']

enexps: []

arlexicons: 'ص'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
