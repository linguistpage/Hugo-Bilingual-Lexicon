---
word: "true"

title: "Discourse Structure"

categories: ['']

tags: ['discourse', 'structure']

arwords: 'تركيب الخطاب'

arexps: []

enwords: ['Discourse Structure']

enexps: []

arlexicons: 'ر'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
