---
word: "true"

title: "Functional Structure"

categories: ['']

tags: ['functional', 'structure']

arwords: 'تركيب وظيفي'

arexps: []

enwords: ['Functional Structure']

enexps: []

arlexicons: ['ر']

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
