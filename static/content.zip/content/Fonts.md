---
word: "true"

title: "Fonts"

categories: ['']

tags: ['Fonts']

arwords: 'حروف مطبعية'
arwords2: 'الخطوط'

arexps: []

enwords: ['Fonts']

enexps: []

arlexicons: 
 - 'ح'
 - 'خ'

enlexicons: 'F'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---