---
word: "true"

title: "Minimization"

categories: ['']

tags: ['Minimization']

arwords: 'ضغط'

arexps: []

enwords: ['Minimization']

enexps: []

arlexicons: 'ض'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---