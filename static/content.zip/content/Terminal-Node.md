---
word: "true"

title: "Terminal Node"

categories: ['']

tags: ['terminal', 'node']

arwords: 'عقدة طرفية'

arexps: []

enwords: ['Terminal Node']

enexps: []

arlexicons: ['ع']

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
