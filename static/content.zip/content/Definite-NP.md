---
word: "true"

title: "Definite NP"

categories: ['']

tags: ['definite', 'np']

arwords: 'عبارة اسمية معرّفة'

arexps: []

enwords: ['Definite NP']

enexps: []

arlexicons: 'ع'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
