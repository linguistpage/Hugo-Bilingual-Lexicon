---
word: "true"

title: "Non-Linear Phonology"

categories: ['']

tags: ['non', 'linear', 'phonology']

arwords: 'علم اﻷصوات اللاخطي'

arexps: []

enwords: ['Non-Linear Phonology']

enexps: []

arlexicons: ['ع']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
