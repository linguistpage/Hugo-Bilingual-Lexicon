---
word: "true"

title: "Dominance Rule"

categories: ['']

tags: ['dominance', 'rule']

arwords: 'قاعدة هيمنة'

arexps: []

enwords: ['Dominance Rule']

enexps: []

arlexicons: 'ق'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
