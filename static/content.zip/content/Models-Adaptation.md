---
word: "true"

title: "Models Adaptation"

categories: ['']

tags: ['Models', 'Adaptation']

arwords: 'تكييف وتحويل النماذج'

arexps: []

enwords: ['Models Adaptation']

enexps: []

arlexicons: 'ك'

enlexicons: 'M'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---