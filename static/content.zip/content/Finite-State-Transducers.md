---
word: "true"

title: "Finite-State Transducers"

categories: ['']

tags: ['finite', 'state', 'transducers']

arwords: 'محولات محدودة الحالة'

arexps: []

enwords: ['Finite-State Transducers']

enexps: []

arlexicons: 'ح'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
