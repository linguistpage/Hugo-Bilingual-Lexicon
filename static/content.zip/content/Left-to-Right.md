---
word: "true"

title: "Left to Right"

categories: ['']

tags: ['Left', 'to', 'Right']

arwords: 'من اليسار إلى اليمين'

arexps: []

enwords: ['Left to Right']

enexps: []

arlexicons: 'م'

enlexicons: 'L'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---