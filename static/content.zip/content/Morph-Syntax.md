---
word: "true"

title: "Morph Syntax"

categories: ['']

tags: ['morph', 'syntax']

arwords: 'نحو صرفي'

arexps: []

enwords: ['Morph Syntax']

enexps: []

arlexicons: 'ن'

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
