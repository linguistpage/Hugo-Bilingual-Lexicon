---
word: "true"

title: "Multi-Linear"

categories: ['']

tags: ['multi', 'linear']

arwords: 'متعدّد الخطية'

arexps: []

enwords: ['Multi-Linear']

enexps: []

arlexicons: ['ع']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
