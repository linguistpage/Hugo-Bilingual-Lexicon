---
word: "true"

title: "Finite-State Transition Networks"

categories: ['']

tags: ['finite', 'state', 'transition', 'networks']

arwords: 'شبكات الانتقال ذات الحالة المحدودة'

arexps: []

enwords: ['Finite-State Transition Networks']

enexps: []

arlexicons: 'ش'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
