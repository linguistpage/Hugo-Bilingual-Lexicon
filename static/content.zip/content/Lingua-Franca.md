---
word: "true"

title: "Lingua Franca"

categories: ['']

tags: ['lingua', 'franca']

arwords: 'لغة مشتركة'

arexps: []

enwords: ['Lingua Franca']

enexps: []

arlexicons: ['ل']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
