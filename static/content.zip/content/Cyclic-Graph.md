---
word: "true"

title: "Cyclic Graph"

categories: ['']

tags: ['cyclic', 'graph']

arwords: 'رسم بياني دائري'

arexps: []

enwords: ['Cyclic Graph']

enexps: []

arlexicons: 'ر'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
