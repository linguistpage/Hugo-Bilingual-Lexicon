---
word: "true"

title: "Syntactic Parse Tree"

categories: ['']

tags: ['syntactic', 'parse', 'tree']

arwords: 'شجرة التحليل النحوية'

arexps: []

enwords: ['Syntactic Parse Tree']

enexps: []

arlexicons: ['ش']

enlexicons: ['S']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
