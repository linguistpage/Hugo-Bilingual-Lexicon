---
word: "true"

title: "Modal Logic"

categories: ['']

tags: ['modal', 'logic']

arwords: 'منطق طوري'

arexps: []

enwords: ['Modal Logic']

enexps: []

arlexicons: 'ن'

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
