---
word: "true"

title: "Dialogue Grammars"

categories: ['']

tags: ['dialogue', 'grammars']

arwords: 'قواعد لغة الحوار'

arexps: []

enwords: ['Dialogue Grammars']

enexps: []

arlexicons: 'ق'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
