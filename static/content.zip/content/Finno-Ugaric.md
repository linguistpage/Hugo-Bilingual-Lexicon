---
word: "true"

title: "Finno-Ugaric"

categories: ['']

tags: ['finno', 'ugaric']

arwords: 'لغات فينية أوغرية'

arexps: []

enwords: ['Finno-Ugaric']

enexps: []

arlexicons: 'ل'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
