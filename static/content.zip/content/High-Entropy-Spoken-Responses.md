---
word: "true"

title: "High Entropy Spoken Responses"

categories: ['']

tags: ['High', 'Entropy', 'Spoken', 'Responses']

arwords: 'اﻹجابات المنطوقة بفوضى مرتفعة'

arexps: []

enwords: ['High Entropy Spoken Responses']

enexps: []

arlexicons: 'ج'

enlexicons: 'H'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---