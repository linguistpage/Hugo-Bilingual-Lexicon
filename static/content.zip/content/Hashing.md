---
word: "true"

title: "Hashing"

categories: ['']

tags: ['hashing']

arwords: 'اختصار'

arexps: []

enwords: ['Hashing']

enexps: []

arlexicons: ['خ']

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
