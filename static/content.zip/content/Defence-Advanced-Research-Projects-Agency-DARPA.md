---
word: "true"

title: "Defence Advanced Research Projects Agency-DARPA"

categories: ['']

tags: ['Defence', 'Advanced', 'Research', 'Projects', 'Agency', 'DARPA']

arwords: 'وكالة مشروعات اﻷبحاث الدفاعية المتقدمة'

arexps: []

enwords: ['Defence Advanced Research Projects Agency-DARPA']

enexps: []

arlexicons: 'و'

enlexicons: 'D'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---