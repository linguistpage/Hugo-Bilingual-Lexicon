---
word: "true"

title: "Informational Structure"

categories: ['']

tags: ['informational', 'structure']

arwords: 'بنية معلوماتية'

arexps: []

enwords: ['Informational Structure']

enexps: []

arlexicons: ['ب']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
