---
word: "true"

title: "Formal Language"

categories: ['']

tags: ['formal', 'language']

arwords: 'لغة شكلية'

arexps: []

enwords: ['Formal Language']

enexps: []

arlexicons: ['ل']

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
