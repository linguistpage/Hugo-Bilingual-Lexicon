---
word: "true"

title: "Expressive"

categories: ['']

tags: ['expressive']

arwords: 'تعبير'

arexps: []

enwords: ['Expressive']

enexps: []

arlexicons: 'ع'

enlexicons: ['E']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
