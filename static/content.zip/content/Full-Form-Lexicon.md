---
word: "true"

title: "Full-Form Lexicon"

categories: ['']

tags: ['full', 'form', 'lexicon']

arwords: 'معجم تام'

arexps: []

enwords: ['Full-Form Lexicon']

enexps: []

arlexicons: 'ع'

enlexicons: ['F']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
