---
word: "true"

title: "Task Orientated"

categories: ['']

tags: ['task', 'orientated']

arwords: 'موجّه نحو مهمّة معينّة'

arexps: []

enwords: ['Task Orientated']

enexps: []

arlexicons: 'و'

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
