---
word: "true"

title: "Translation into Higher-Order Logic"

categories: ['']

tags: ['translation', 'into', 'higher', 'order', 'logic']

arwords: 'الترجمة إلى منطق من الدرجة اﻷعلى'

arexps: []

enwords: ['Translation into Higher-Order Logic']

enexps: []

arlexicons: ['ت']

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
