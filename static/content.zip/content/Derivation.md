---
word: "true"

title: "Derivation"

categories: ['']

tags: ['derivation']

arwords: 'اشتقاق'

arexps: []

enwords: ['Derivation']

enexps: []

arlexicons: 'ش'

enlexicons: ['D']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
