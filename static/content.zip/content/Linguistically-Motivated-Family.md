---
word: "true"

title: "Linguistically-Motivated Family"

categories: ['']

tags: ['linguistically', 'motivated', 'family']

arwords: 'عائلة متحفّزة لغوياً'

arexps: []

enwords: ['Linguistically-Motivated Family']

enexps: []

arlexicons: ['ع']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
