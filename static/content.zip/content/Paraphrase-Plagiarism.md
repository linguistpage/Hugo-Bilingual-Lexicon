---
word: "true"

title: "Paraphrase Plagiarism"

categories: ['']

tags: ['Paraphrase', 'Plagiarism']

arwords: 'الاحتيال عن طريق إعادة الصياغة'

arexps: []

enwords: ['Paraphrase Plagiarism']

enexps: []

arlexicons: 'ح'

enlexicons: 'P'

authors: ['Ruqayya Roshdy']

translators: ['X']

citations: 'تطبيقات أساسية في المعالجة الآلية للغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---