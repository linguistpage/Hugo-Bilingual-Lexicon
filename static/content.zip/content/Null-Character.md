---
word: "true"

title: "Null Character"

categories: ['']

tags: ['null', 'character']

arwords: 'حرف فارغ'

arexps: []

enwords: ['Null Character']

enexps: []

arlexicons: ['ح']

enlexicons: ['N']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
