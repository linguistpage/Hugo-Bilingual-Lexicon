---
word: "true"

title: "Implicature"

categories: ['']

tags: ['implicature']

arwords: 'إشارة ضمنية'

arexps: []

enwords: ['Implicature']

enexps: []

arlexicons: ['ش']

enlexicons: ['I']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
