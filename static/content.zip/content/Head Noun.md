---
word: "true"

title: "Head Noun"

categories: ['']

tags: ['head', 'noun']

arwords: 'اسم رئيسي'

arexps: []

enwords: ['Head Noun']

enexps: []

arlexicons: ['أ']

enlexicons: ['H']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
