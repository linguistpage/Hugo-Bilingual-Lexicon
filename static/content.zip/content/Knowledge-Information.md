---
word: "true"

title: "Knowledge Information"

categories: ['']

tags: ['knowledge', 'information']

arwords: 'معلومات معرفية'

arexps: []

enwords: ['Knowledge Information']

enexps: []

arlexicons: 'ع'

enlexicons: ['K']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
