---
word: "true"

title: "Statistical Machine Translation"

categories: ['']

tags: ['Statistical', 'Machine', 'Translation']

arwords: 'الترجمة الآلية الإحصائية'

arexps: []

enwords: ['Statistical Machine Translation']

enexps: []

arlexicons: 'ت'

enlexicons: 'S'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---