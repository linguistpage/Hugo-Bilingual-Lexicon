---
word: "true"

title: "Etymological Information"

categories: ['']

tags: ['Etymological', 'Information']

arwords: 'المعلومات التأثيلية'

arexps: []

enwords: ['Etymological Information']

enexps: []

arlexicons: 'ع'

enlexicons: 'E'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---