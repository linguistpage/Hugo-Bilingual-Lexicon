---
word: "true"

title: "Multi-Tape Machine"

categories: ['']

tags: ['multi', 'tape', 'machine']

arwords: 'جهاز متعدّد الأشرطة'

arexps: []

enwords: ['Multi-Tape Machine']

enexps: []

arlexicons: ['ج']

enlexicons: ['M']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
