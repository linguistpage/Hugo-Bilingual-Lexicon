---
word: "true"

title: "Complementary Distribution"

categories: ['']

tags: ['complementary', 'distribution']

arwords: 'توزيع تكاملي'

arexps: []

enwords: ['Complementary Distribution']

enexps: []

arlexicons: 'و'

enlexicons: ['C']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
