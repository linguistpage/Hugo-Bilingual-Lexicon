---
word: "true"

title: "Linear Precedence"

categories: ['']

tags: ['linear', 'precedence']

arwords: 'إدارة الحوار'

arexps: []

enwords: ['Linear Precedence']

enexps: []

arlexicons: ['أ']

enlexicons: ['L']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
