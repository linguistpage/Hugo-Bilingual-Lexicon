---
word: "true"

title: "Theme"

categories: ['']

tags: ['theme']

arwords: 'موضوع'

arexps: []

enwords: ['Theme']

enexps: []

arlexicons: 'و'

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
