---
word: "true"

title: "Adverb Phrase-AP"

categories: ['']

tags: ['Adverb', 'Phrase', 'AP']

arwords: 'مركب ظرفي'

arexps: []

enwords: ['Adverb Phrase-AP']

enexps: []

arlexicons: 'ر'

enlexicons: 'A'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---