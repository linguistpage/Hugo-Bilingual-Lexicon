---
word: "true"

title: "Image Processing"

categories: ['']

tags: ['Image', 'Processing']

arwords: 'معالجة الصور'

arexps: []

enwords: ['Image Processing']

enexps: []

arlexicons: 'ع'

enlexicons: 'I'

authors: ['Ruqayya Roshdy']

translators: ['']

citations: 'مقدمة في حوسبة اللغة العربية'

sources: 'مركز الملك عبدالله بن عبدالعزيز الدولي لخدمة اللغة العربية'

slug: ""
---