---
word: "true"

title: "Allomorph"

categories: ['']

tags: ['allomorph']

arwords: 'البدل الصرفي'

arexps: []

enwords: ['Allomorph']

enexps: []

arlexicons: 'أ'

enlexicons: ['A']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['Wikipedia']

sources: 'https://ar.wikipedia.org/wiki/%D8%A8%D8%AF%D9%84_%D8%B5%D8%B1%D9%81%D9%8A#cite_note-1'

slug: ""
---

**البدل الصرفي**[[1]](https://ar.wikipedia.org/wiki/%D8%A8%D8%AF%D9%84_%D8%B5%D8%B1%D9%81%D9%8A#cite_note-1) ([بالإنجليزية](https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D8%A9_%D8%A7%D9%84%D8%A5%D9%86%D8%AC%D9%84%D9%8A%D8%B2%D9%8A%D8%A9 "اللغة الإنجليزية"): allomorph)‏ هو كل [نوع](https://ar.wikipedia.org/wiki/%D8%AA%D9%86%D9%88%D8%B9_(%D9%84%D8%BA%D8%A9) "تنوع (لغة)") من أنواع [المقطع الصرفي](https://ar.wikipedia.org/wiki/%D9%85%D9%82%D8%B7%D8%B9_%D8%B5%D8%B1%D9%81%D9%8A "مقطع صرفي")[[2]](https://ar.wikipedia.org/wiki/%D8%A8%D8%AF%D9%84_%D8%B5%D8%B1%D9%81%D9%8A#cite_note-2) الذي يتغير وفقا للسياق الذي جاء فيه[[3]](https://ar.wikipedia.org/wiki/%D8%A8%D8%AF%D9%84_%D8%B5%D8%B1%D9%81%D9%8A#cite_note-3) دون أن يتغير معناه.
