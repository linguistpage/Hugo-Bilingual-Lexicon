---
word: "true"

title: "Preposition"

categories: ['']

tags: ['preposition']

arwords: 'حرف جر'

arexps: []

enwords: ['Preposition']

enexps: []

arlexicons: ['ح']

enlexicons: ['P']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['دليل أكسفورد في السانيات الحاسوبية']

sources: ['المنظمة العربية للترجمة']


---
