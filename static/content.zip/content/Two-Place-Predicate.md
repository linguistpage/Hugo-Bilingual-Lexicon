---
word: "true"

title: "Two-Place Predicate"

categories: ['']

tags: ['two', 'place', 'predicate']

arwords: 'مسند ذو متعلقتين'

arexps: []

enwords: ['Two-Place Predicate']

enexps: []

arlexicons: 'س'

enlexicons: ['T']

authors: ['Ruqayya Roshdy']

translators: ['Tarek Ibrahim']

citations: ['oxford guide for computational linguistics']

sources: ['المنظمة العربية للترجمة']

slug: ""
---
